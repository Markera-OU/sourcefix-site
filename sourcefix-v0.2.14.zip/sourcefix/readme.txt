=== SourceFix ===
Contributors: sourcefix
Donate link: https://usesourcefix.com
Tags: accessibility, alt text, headings, link text, ai
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 0.2.14
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI-assisted accessibility fixes at publish time: alt text, link text, and heading structure, with an approval queue and a dated public statement.

== Description ==

SourceFix scans your posts and pages when they are published or updated and finds three common accessibility issues:

* Images missing alt text
* Links with poor link text ("click here", "read more", bare URLs)
* Heading structure problems (missing H1, multiple H1s, skipped levels)

For images and headings, SourceFix asks its AI authoring service to write a fix. Low-risk alt text fixes are applied automatically when the context is clear; everything else goes to an approval queue where you review, edit, and approve or reject each fix with one click. Every fix that is applied is written to an audit log, and a dated public statement page lists what was fixed and when.

SourceFix does not claim your site complies with any accessibility standard. The statement it publishes describes the fixes that were applied; it is a record of work done, not a compliance claim.

= What the free version includes =

* Publish-time scanning for posts and pages
* AI-authored alt text and heading fixes (up to 50 AI fixes per month)
* Approval queue with one-click approve and reject, and editable proposed text
* Auto-apply for low-risk alt text fixes (off by default; turn it on in Settings)
* Per-site terminology memory, so the AI writes fixes in your site's own words
* Audit log of every fix applied (kept 12 months); the public statement lists applied fixes from the last 12 months
* Dated public accessibility statement page (date refreshed whenever a fix is applied)
* Agency dashboard and downloadable client reports (CSV)

= Paid plans =

* Solo ($79/year, 1 site): unlimited AI-authored fixes.
* Studio ($149/year, 5 sites): unlimited AI-authored fixes.
* Agency ($299/year, 25 sites): unlimited AI-authored fixes.

Paid plans differ from Free only in the AI-authoring allowance: the Free plan is capped at 50 AI fixes per month, paid plans are unlimited. Every feature in the plugin works the same on every plan. Billing is handled by Freemius. You can upgrade from the Settings page.

= How it works =

1. Publish or update a post or page. Publishing returns immediately; the scan runs in the background right after, so publishing never waits on the AI service.
2. SourceFix scans the content and, where needed, asks the AI authoring service for a fix.
3. Low-risk alt text fixes are applied automatically. Other fixes wait in the Fix Queue for your approval.
4. The public statement page is re-dated every time a fix is applied.

= Privacy =

SourceFix sends the text around an image and the list of headings on a page to its AI authoring service (hosted at backend-production-2abf.up.railway.app), which forwards them to DeepSeek, the AI provider, so the service can write alt text and correct heading structure. Your site's terminology list is sent with the request so the AI writes in your site's own words. No other content is sent.

The service is contacted only after you connect this site: on activation SourceFix does not register or contact the service. Click "Connect to the AI authoring service" on the SourceFix screens (or the Settings page) to connect; until then scans still detect issues and queue them for you to write by hand.

What the service stores: only your site's address, its plan, and how many AI fixes it has used this month (to enforce the Free plan's 50-fix monthly cap). It stores no post content and no fix history. Your approval history (which fixes were approved or rejected), your audit log, and your terminology list are stored only on your own site, in its WordPress database. Nothing else is tracked.

== Installation ==

1. Download the plugin zip from https://usesourcefix.com/sourcefix-v0.2.14.zip.
2. In WordPress, go to Plugins > Add New > Upload Plugin, choose the zip, and activate it. Or unzip the `sourcefix` folder into `/wp-content/plugins/` and activate it.
3. On activation, SourceFix creates a DRAFT page called "Accessibility Statement". Review it under Pages and publish it when you are ready; nothing is published without your say-so. It also adds a Fix Queue, Audit Log, Settings, and Agency under the SourceFix menu. Activation contacts no external service: to get AI-written fixes, click "Connect to the AI authoring service" when the notice appears; until you connect, scans still detect issues and queue them for manual writing.
4. Publish or update a post to see the first scan results.

The WordPress.org listing is pending review, so the directory install is not available yet. Once it is live, you will also be able to install SourceFix from Plugins > Add New by searching for "SourceFix".

== Frequently Asked Questions ==

= Does SourceFix make my site compliant with WCAG or the European Accessibility Act? =

No. SourceFix finds and fixes common issues, and records what it fixed. It does not claim compliance with WCAG, the EAA, or any other standard, and it does not audit your whole site.

= What happens if the AI service is unavailable? =

Publishing is never blocked. Issues are still detected and queued for manual review, and the failure is logged.

= Can I turn off automatic fixes? =

Yes. Settings has an "Auto-apply low-risk fixes" checkbox. With it off, every fix waits in the queue for your approval.

= What counts as a low-risk fix? =

Alt text for an informative image where the surrounding copy gives clear context and the AI returned a confident, non-empty result. Decorative images get an empty alt attribute, which is also applied automatically. Heading and link fixes always go to the queue.

== Screenshots ==

1. The Fix Queue, with proposed fixes ready to approve or reject.
2. The Settings page.
3. The public accessibility statement.

== Changelog ==

= 0.2.14 =
* WordPress.org review fixes. Every feature built into the plugin now works on every plan: auto-apply for low-risk fixes, per-site terminology memory, the 12-month audit log and fix history, and the agency dashboard with client reports are no longer tied to a paid plan. Paid plans (Solo $79/year, Studio $149/year, Agency $299/year) now differ from Free only in the AI-authoring allowance — Free is capped at 50 AI fixes per month, paid plans are unlimited — and that cap is enforced by the authoring service, not by the plugin. The audit log and the public statement now keep 12 months of history for every site.
* Activation no longer contacts the authoring service. The site is registered only when you click "Connect to the AI authoring service" on the SourceFix screens or the Settings page; until you connect, scans still detect issues and queue them for manual writing. Sites that already connected keep working exactly as before.
* The Freemius SDK is no longer loaded a second time when another active plugin already loaded it, so two Freemius-powered plugins can no longer fatal on activation.
* The plugin no longer calls load_plugin_textdomain(): WordPress loads translations automatically (the plugin requires WordPress 6.0 or later).

= 0.2.13 =
* The Agency client report (CSV download) can no longer be used to smuggle a spreadsheet formula into the file: any cell starting with `=`, `+`, `-`, `@`, a tab, or a carriage return — including after leading spaces — is now prefixed with a single quote, so Excel and Google Sheets treat it as plain text. This covers all four columns (date, post title, field type, fix text), not just the fix text. Normal values are unchanged.

= 0.2.12 =
* The accessibility statement's "Last updated" date is now refreshed whenever a fix is applied, on every plan. Previously the date froze on the Free plan after activation while fixes kept being applied and listed with newer dates, so the headline date disagreed with the list below it. The Free plan's limit is the 30-day history, not a frozen date.

= 0.2.11 =
* Activating the plugin no longer publishes a public Accessibility Statement page. The page is now created as a draft, and a notice on the SourceFix screens points you at it to review and publish when you are ready. If a page with the statement shortcode already exists (published or draft), it is reused instead of creating a duplicate. Uninstalling the plugin now removes the statement page it created, but only if you never edited it: a page you changed or added your own text to is left alone.

= 0.2.10 =
* Applied and rejected fixes are now kept only for the plan retention, like the audit log: 30 days on Free, 12 months on paid plans. The daily maintenance prunes older fix rows, and the public statement lists only fixes inside the retention, so it no longer shows fixes from long past the advertised period. Fixes still waiting in the approval queue are never pruned, however old. A rejected fix older than the retention is forgotten with the rest of the history, so a later re-scan of the same unchanged content may propose it again.

= 0.2.9 =
* Rejecting a fix is now final: a fix you reject stays rejected and is not queued again when the post is re-scanned, and the re-scan no longer spends an AI call on it. If you edit the underlying content (for example the link text or the heading structure), the old rejection no longer applies and the changed content can get a new fix. Rejected fixes stay visible in the queue history as rejected.

= 0.2.8 =
* Auto-apply is now off by default. On a new install, low-risk alt text fixes wait in the approval queue until you turn on "Auto-apply low-risk fixes" in Settings. Existing installs keep their current setting: if auto-apply was on, it stays on until you turn it off.

= 0.2.7 =
* Turning off "Auto-apply low-risk fixes" now actually turns it off. The settings form was missing the hidden field that carries a `0` when the checkbox is unchecked, so saving with the box unchecked left auto-apply on. Unchecking now stores `0` and every fix waits in the approval queue; checking stores `1` as before.

= 0.2.6 =
* Approving a fix now applies exactly what was approved. Heading fixes apply the approved reworded text together with the level, so a heading whose text changes but whose level does not now applies instead of erroring. Identical images and links are fixed one at a time, by their position in the post: the second identical image gets its own fix instead of being marked applied while it still has no alt text. After every apply, the post is re-scanned, so anything still wrong stays queued and is reported in the audit log instead of being silently treated as fixed. The fixes table gains an `occurrence` column to tell identical elements apart; it is added automatically when you update, and the queue now labels the second and later occurrences.
* A re-scan now reuses a fix that is already queued instead of asking the AI to author the same fix again, so re-publishing a post no longer spends extra AI calls on fixes you have already seen.

= 0.2.5 =
* Paying sites no longer silently drop to the Free plan when Freemius is temporarily unavailable: the last known paid plan is now cached, and the site keeps its paid features for a 14-day grace period while Freemius cannot confirm the licence. Only an expired or cancelled licence downgrades immediately. The daily audit-log prune never deletes below the paid 12-month retention while the cached plan is active, and an admin notice explains the situation while the site runs on the cached plan.

= 0.2.4 =
* Publishing no longer waits for the scan: when you publish or update a post, SourceFix now schedules the scan as a background task (WP-Cron) and publishing returns immediately. The scan runs moments later and fills the approval queue exactly as before — same fixes, same auto-apply rules. If the AI service is down, fixes still queue for manual review. A post with many images can no longer delay publishing.

= 0.2.3 =
* Applying a fix no longer rewrites the whole post: each fix now splices only its own fragment into the original content, and the rest of the post is verified byte-identical. Gutenberg block markup, shortcodes, and inline script/style content are left untouched. If a fix's target cannot be matched unambiguously (no match, more than one match, or a heading count that changed since the scan), the fix is left pending with an audit-log entry explaining why, instead of rewriting the post.
* Every applied fix is now noted on the revision the update creates, so the change is visible in post history.

= 0.2.2 =
* The authoring service no longer stores any fix history: approval history, terminology memory, and the audit log live only on your site, in its WordPress database. The service stores only your site address, plan, and monthly usage count. The Privacy section now states this, and names DeepSeek as the AI provider.
* Your site's terminology is now used for heading fixes as well as alt text (Studio and above). Auto-apply safety now measures the real surrounding copy, so terminology alone cannot green-light auto-apply on a context-free image.

= 0.2.1 =
* The authoring service now requires a per-site API key: the plugin registers this site on activation and sends the key with every authoring request. The Free 50-fix monthly cap is enforced server-side. Version 0.2.0 can no longer author fixes against the service, so please update to 0.2.1.
* Paid-plan overrides are test-only now: without the test file, no code on the site can unlock a paid plan.

= 0.2.0 =
* Freemius billing: Free, Solo ($79/year), Studio ($149/year), and Agency ($299/year) plans. Free is capped at 50 AI fixes per month; paid plans have unlimited authoring. Auto-apply, statement re-publishing, and the 12-month audit log are Solo and above; terminology memory is Studio and above; the agency dashboard and client reports are Agency only.
* Dated public statement is published once on the Free plan and re-published on every change on paid plans.

= 0.1.0 =
* First release: publish-time scanning, AI-authored alt text and heading fixes, approval queue, audit log, dated public statement.

== Upgrade Notice ==

= 0.2.14 =
* All built-in features now work on every plan, and activation no longer contacts the authoring service — click "Connect to the AI authoring service" after updating if this site is not connected yet. No action needed otherwise; update as usual.

= 0.2.13 =
* The Agency client report now guards CSV cells against spreadsheet formula injection. No action needed; update as usual.

= 0.2.12 =
* The statement date now refreshes on every fix applied, on every plan. No action needed; update as usual.

= 0.2.11 =
* The accessibility statement page is now created as a draft on activation, not published. If you already published your statement page, nothing changes. No action needed; update as usual.

= 0.2.10 =
* Fix history now follows the plan retention (30 days Free, 12 months paid). No action needed; update as usual.

= 0.2.9 =
* Rejected fixes no longer come back on re-scan. No action needed; update as usual.

= 0.2.8 =
* New installs now start with auto-apply off; existing installs keep their current setting. No action needed; update as usual.

= 0.2.7 =
* Settings fix: unchecking "Auto-apply low-risk fixes" now actually turns auto-apply off. No action needed; update as usual.

= 0.2.6 =
* Correctness fix: approved fixes now land exactly as approved (heading text included), identical images and links are fixed one at a time, and the post is re-scanned after every apply. No action needed; update as usual.

= 0.2.5 =
* Safety fix: a paying site now keeps its paid plan for 14 days when Freemius cannot confirm the licence, instead of dropping to Free. No action needed; update as usual.

= 0.2.4 =
* Publishing is now instant: the scan runs in the background after you publish. No action needed; update as usual.

= 0.2.3 =
* Safety fix: applying a fix now touches only its own fragment of the post and aborts instead of rewriting when the target is ambiguous. No action needed; update as usual.

= 0.2.2 =
* Honesty fix: the authoring service stores no fix history. The Privacy section now says so, and names DeepSeek. Terminology now applies to heading fixes too.

= 0.2.1 =
* Required update: the authoring service now requires a per-site API key, which 0.2.1 registers automatically. Version 0.2.0 can no longer author fixes.

= 0.2.0 =
* Freemius billing and plan-gated features. Free-plan behaviour is unchanged apart from auto-apply, which is now a Solo feature: on Free, every fix waits in the approval queue.

= 0.1.0 =
* First release.
