<?php
/**
 * Plugin Name:       SourceFix
 * Plugin URI:        https://usesourcefix.com
 * Description:       AI-assisted accessibility fixes at publish time. SourceFix scans new and updated posts for images missing alt text, poor link text, and heading structure issues, authors fixes with AI, and keeps an approval queue so you stay in control. A dated statement records what was fixed.
 * Version:           0.2.11
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Markera OÜ
 * Author URI:        https://markera.co
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       sourcefix
 * Domain Path:       /languages
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SOURCEFIX_VERSION', '0.2.11' );
define( 'SOURCEFIX_PLUGIN_FILE', __FILE__ );
define( 'SOURCEFIX_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SOURCEFIX_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
// Default backend API URL. The admin can override it on the settings page.
define( 'SOURCEFIX_API_URL', 'https://backend-production-2abf.up.railway.app' );
// Free tier: AI-authored fixes per calendar month.
define( 'SOURCEFIX_FREE_MONTHLY_FIXES', 50 );

/**
 * Freemius product credentials.
 *
 * Fill these in after creating the product in the Freemius Developer
 * Dashboard (see plugin/freemius-config.md for the exact steps). The
 * public key is not secret; the secret key is never stored in this repo.
 * Until the product is registered, the plugin runs as the Free tier and
 * the Freemius SDK is not loaded.
 */
define( 'SOURCEFIX_FS_ID', 44509 );
define( 'SOURCEFIX_FS_PUBLIC_KEY', 'pk_f5a97fb9fdac57c555b57729f963e' );

/**
 * Initialize the Freemius SDK.
 *
 * Guarded: when the product is not registered yet (ID/key empty), the
 * SDK is skipped and the plugin behaves as the Free tier. The array is
 * passed literally to fs_dynamic_init, as Freemius requires.
 */
if ( ! function_exists( 'sourcefix_fs' ) ) {
	function sourcefix_fs() {
		global $sourcefix_fs;
		if ( ! isset( $sourcefix_fs ) ) {
			if ( SOURCEFIX_FS_ID && '' !== SOURCEFIX_FS_PUBLIC_KEY ) {
				require_once SOURCEFIX_PLUGIN_DIR . 'freemius/start.php';
				$sourcefix_fs = fs_dynamic_init(
					array(
						'id'                  => SOURCEFIX_FS_ID,
						'slug'                => 'sourcefix',
						'type'                => 'plugin',
						'public_key'          => SOURCEFIX_FS_PUBLIC_KEY,
						'is_premium'          => false,
						'has_premium_version' => true,
						'has_paid_plans'      => true,
						'is_org_compliant'    => true,
						'menu'                => array(
							'slug'    => 'sourcefix',
							'account' => true,
							'pricing' => true,
							'support' => true,
							'contact' => true,
						),
					)
				);
			} else {
				$sourcefix_fs = null;
			}
		}
		return $sourcefix_fs;
	}
	sourcefix_fs();
	do_action( 'sourcefix_fs_loaded' );
}

require_once SOURCEFIX_PLUGIN_DIR . 'includes/class-sourcefix-licensing.php';
require_once SOURCEFIX_PLUGIN_DIR . 'includes/class-sourcefix-store.php';
require_once SOURCEFIX_PLUGIN_DIR . 'includes/class-sourcefix-api.php';

// Test-only paid-plan overrides. The file is NEVER shipped (it must be
// excluded from the release zip and the WordPress.org submission); when
// it is absent, the override block in current_plan() is dead code and
// no code on the site can unlock a paid plan.
if ( file_exists( SOURCEFIX_PLUGIN_DIR . 'includes/test-overrides.php' ) ) {
	require_once SOURCEFIX_PLUGIN_DIR . 'includes/test-overrides.php';
}
require_once SOURCEFIX_PLUGIN_DIR . 'includes/class-sourcefix-scanner.php';
require_once SOURCEFIX_PLUGIN_DIR . 'includes/class-sourcefix-applier.php';
require_once SOURCEFIX_PLUGIN_DIR . 'includes/sourcefix-publish.php';
require_once SOURCEFIX_PLUGIN_DIR . 'includes/class-sourcefix-statement.php';
require_once SOURCEFIX_PLUGIN_DIR . 'admin/class-sourcefix-admin.php';

/**
 * Activation: create the database tables, set defaults, create the
 * statement page, and record the activation in the audit log.
 */
function sourcefix_activate() {
	SourceFix_Store::create_tables();
	update_option( 'sourcefix_db_version', SOURCEFIX_VERSION );

	add_option( 'sourcefix_api_url', SOURCEFIX_API_URL );
	// Auto-apply defaults to OFF on new installs (audit M-2): the
	// admin opts in from Settings after seeing the approval queue
	// once. add_option() never overwrites an existing value, so
	// upgrading installs keep whatever the admin already chose.
	add_option( 'sourcefix_auto_apply', '0' );
	add_option( 'sourcefix_month_key', gmdate( 'Y-m' ) );
	add_option( 'sourcefix_month_count', 0 );

	// Register this site with the backend and store its API key. The
	// backend requires a key for every authoring call; registration is
	// best-effort here (a failed registration is retried lazily on the
	// first API call) and must never break activation.
	SourceFix_API::ensure_registered();

	SourceFix_Statement::maybe_create_page();

	// Daily maintenance: prune the audit log and the fixes table to
	// the plan's retention (Free: 30 days, paid: 12 months).
	if ( ! wp_next_scheduled( 'sourcefix_daily_maintenance' ) ) {
		wp_schedule_event( time(), 'daily', 'sourcefix_daily_maintenance' );
	}

	SourceFix_Store::audit_log( 0, 'plugin_activated', __( 'SourceFix activated.', 'sourcefix' ) );
}
register_activation_hook( __FILE__, 'sourcefix_activate' );

/**
 * Deactivation: nothing destructive. Tables and options stay so a
 * re-activation keeps the approval history. The maintenance cron is
 * cleared; it is re-registered on the next activation.
 */
function sourcefix_deactivate() {
	wp_clear_scheduled_hook( 'sourcefix_daily_maintenance' );
	SourceFix_Store::audit_log( 0, 'plugin_deactivated', __( 'SourceFix deactivated.', 'sourcefix' ) );
}
register_deactivation_hook( __FILE__, 'sourcefix_deactivate' );

/**
 * Daily maintenance: prune the audit log and the fixes table to the
 * current plan's retention. The prune never goes below the last known
 * paid retention: while a cached paid plan is inside its grace period
 * (audit H-6) the floor is the paid 12 months, even if Freemius is
 * temporarily unreachable. The same rule governs both tables (audit
 * M-4): the fixes table is pruned on the same schedule, so the public
 * statement never lists fixes past the plan's stated retention.
 */
function sourcefix_daily_maintenance() {
	$days    = max( SourceFix_Licensing::audit_retention_days(), SourceFix_Licensing::cached_retention_days() );
	$deleted = SourceFix_Store::prune_audit_log( $days );
	if ( $deleted > 0 ) {
		SourceFix_Store::audit_log( 0, 'audit_pruned', sprintf( __( 'Removed %d audit log entries older than the plan retention.', 'sourcefix' ), $deleted ) );
	}
	$fixes_deleted = SourceFix_Store::prune_fixes( $days );
	if ( $fixes_deleted > 0 ) {
		SourceFix_Store::audit_log( 0, 'fixes_pruned', sprintf( __( 'Removed %d applied or rejected fixes older than the plan retention.', 'sourcefix' ), $fixes_deleted ) );
	}
}
add_action( 'sourcefix_daily_maintenance', 'sourcefix_daily_maintenance' );

/**
 * Load translations.
 */
function sourcefix_load_textdomain() {
	load_plugin_textdomain( 'sourcefix', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
add_action( 'init', 'sourcefix_load_textdomain' );

/**
 * Register the admin screens and the public statement shortcode.
 *
 * Also runs the database migration: plugin updates do NOT re-run the
 * activation hook, so a schema change (audit H-8 added the `occurrence`
 * column to the fixes table) would never land on an updated site
 * otherwise. create_tables() is idempotent (dbDelta adds only what is
 * missing) and runs at most once per version.
 */
function sourcefix_init() {
	if ( SOURCEFIX_VERSION !== get_option( 'sourcefix_db_version', '' ) ) {
		SourceFix_Store::create_tables();
		update_option( 'sourcefix_db_version', SOURCEFIX_VERSION );
	}
	SourceFix_Admin::init();
	SourceFix_Statement::init();
}
add_action( 'init', 'sourcefix_init' );
