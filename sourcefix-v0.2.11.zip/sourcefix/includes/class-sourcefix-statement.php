<?php
/**
 * The public accessibility statement.
 *
 * The statement lists what SourceFix has actually fixed on this site and
 * when. It is a dated record of work done, not a claim of compliance: it
 * never says the site is compliant with WCAG, the European Accessibility
 * Act, or any other standard.
 *
 * The statement lives on a page the plugin creates on activation (title
 * "Accessibility Statement") containing the [sourcefix_statement]
 * shortcode. Its "last updated" date is refreshed every time a fix is
 * applied.
 *
 * Audit M-5: the page is created as a DRAFT, never published.
 * Publishing a public page is the admin's decision, so activation only
 * prepares the draft and an admin notice points at it to review and
 * publish. Uninstall removes the page again, but only if it is still
 * exactly the untouched page the plugin created.
 *
 * @package SourceFix
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SourceFix_Statement {

	/**
	 * Shortcode tag.
	 */
	const SHORTCODE = 'sourcefix_statement';

	/**
	 * Register the shortcode.
	 */
	public static function init() {
		add_shortcode( self::SHORTCODE, array( __CLASS__, 'render_shortcode' ) );
	}

	/**
	 * Create the statement page on activation if it does not exist yet.
	 * The page contains only the shortcode, so the statement is always
	 * rendered from the live fix history.
	 *
	 * Audit M-5: the page is created as a DRAFT, never published.
	 * Publishing a public page is the admin's decision: an admin notice
	 * on the SourceFix screens points at the draft to review and
	 * publish. A page that already contains the shortcode (published
	 * or draft) is reused, never duplicated.
	 */
	public static function maybe_create_page() {
		$existing = get_option( 'sourcefix_statement_page_id', 0 );
		if ( $existing && get_post( $existing ) ) {
			return (int) $existing;
		}

		// Do not create a duplicate if a page with the shortcode already exists.
		// Drafts count too: a draft this plugin created on an earlier
		// activation (or the admin's own draft) is reused, not duplicated.
		$pages = get_posts(
			array(
				'post_type'   => 'page',
				'post_status' => array( 'publish', 'draft' ),
				'numberposts' => -1,
				's'           => '[' . self::SHORTCODE . ']',
			)
		);
		if ( ! empty( $pages ) ) {
			update_option( 'sourcefix_statement_page_id', $pages[0]->ID );
			return (int) $pages[0]->ID;
		}

		$page_id = wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_title'   => __( 'Accessibility Statement', 'sourcefix' ),
				'post_content' => '[' . self::SHORTCODE . ']',
				'post_status'  => 'draft',
			)
		);
		if ( $page_id && ! is_wp_error( $page_id ) ) {
			update_option( 'sourcefix_statement_page_id', $page_id );
			SourceFix_Store::audit_log( $page_id, 'statement_created', __( 'Accessibility statement page created as a draft.', 'sourcefix' ) );
			self::touch();
			return (int) $page_id;
		}
		return 0;
	}

	/**
	 * Remove the statement page on uninstall — but only if it is still
	 * exactly the page this plugin created (audit M-5).
	 *
	 * Deletes only when BOTH hold:
	 * - the stored `sourcefix_statement_page_id` still points at a page, and
	 * - that page's content is still only the shortcode.
	 * If the admin edited the page, added their own text, or published
	 * custom content, the page is theirs now and is left alone.
	 *
	 * Force-deleted (no trash): uninstall already removes the plugin's
	 * tables and options irreversibly, and a trashed page would linger
	 * with a dead shortcode. Nothing the admin wrote is ever deleted:
	 * the content check above guarantees the page holds no admin text.
	 *
	 * @return bool True when a page was deleted.
	 */
	public static function delete_page_on_uninstall() {
		$page_id = (int) get_option( 'sourcefix_statement_page_id', 0 );
		if ( ! $page_id ) {
			return false;
		}
		$page = get_post( $page_id );
		if ( ! $page || 'page' !== $page->post_type ) {
			return false;
		}
		if ( '[' . self::SHORTCODE . ']' !== trim( (string) $page->post_content ) ) {
			return false;
		}
		return (bool) wp_delete_post( $page_id, true );
	}

	/**
	 * Refresh the statement's "last updated" date. Called whenever a fix
	 * is applied. On the Free plan the statement is published once (the
	 * first touch sets the date and later touches are no-ops); paid plans
	 * re-date it on every change.
	 */
	public static function touch() {
		$existing = get_option( 'sourcefix_statement_updated', '' );
		if ( '' !== $existing && ! SourceFix_Licensing::allows_statement_republish() ) {
			return;
		}
		update_option( 'sourcefix_statement_updated', current_time( 'mysql' ) );
	}

	/**
	 * Render the shortcode.
	 *
	 * Audit M-4: the statement lists only applied fixes inside the
	 * plan's retention (Free: 30 days, paid: 12 months, with the H-6
	 * fail-closed floor — a cached paid plan keeps the paid 12 months
	 * while Freemius cannot confirm the licence). The daily prune
	 * keeps the table in-retention, but the query filters by the same
	 * rule as well, so a fix that aged past retention since the last
	 * daily run is not listed either: the statement's retention always
	 * matches the advertised plan retention, never the prune schedule.
	 *
	 * @param array $atts Shortcode attributes (unused).
	 * @return string
	 */
	public static function render_shortcode( $atts ) {
		$updated = get_option( 'sourcefix_statement_updated', '' );
		$days    = max( SourceFix_Licensing::audit_retention_days(), SourceFix_Licensing::cached_retention_days() );
		$fixes   = SourceFix_Store::get_applied_fixes( 200, $days );

		$out = '<div class="sourcefix-statement">';
		$out .= '<p>' . esc_html__( 'This page records the accessibility fixes applied to this site by the SourceFix plugin. Each entry shows what was fixed and when.', 'sourcefix' ) . '</p>';
		$out .= '<p><strong>' . esc_html__( 'Last updated:', 'sourcefix' ) . '</strong> ' . esc_html( $updated ? date_i18n( get_option( 'date_format' ), strtotime( $updated ) ) : __( 'Not yet updated', 'sourcefix' ) ) . '</p>';

		if ( empty( $fixes ) ) {
			$out .= '<p>' . esc_html__( 'No fixes have been applied yet.', 'sourcefix' ) . '</p>';
		} else {
			$out .= '<ul>';
			foreach ( $fixes as $fix ) {
				$out .= '<li>' . esc_html( self::fix_line( $fix ) ) . '</li>';
			}
			$out .= '</ul>';
		}

		$out .= '<p><em>' . esc_html__( 'This statement describes the fixes that have been applied. It is not a claim that this site complies with WCAG, the European Accessibility Act, or any other accessibility standard.', 'sourcefix' ) . '</em></p>';
		$out .= '</div>';

		return $out;
	}

	/**
	 * One line describing an applied fix.
	 *
	 * @param object $fix Fix row.
	 * @return string
	 */
	private static function fix_line( $fix ) {
		$date  = date_i18n( get_option( 'date_format' ), strtotime( $fix->decided_at ? $fix->decided_at : $fix->created_at ) );
		$title = get_the_title( (int) $fix->post_id );
		$title = '' !== $title ? $title : sprintf(
			/* translators: %d: post ID. */
			__( 'Post #%d', 'sourcefix' ),
			$fix->post_id
		);

		switch ( $fix->field_type ) {
			case SourceFix_Store::TYPE_ALT:
				if ( '' === $fix->proposed_text ) {
					return sprintf(
						/* translators: %1$s: date, %2$s: post title. */
						__( '%1$s: marked an image as decorative (empty alt text) in "%2$s".', 'sourcefix' ),
						$date,
						$title
					);
				}
				return sprintf(
					/* translators: %1$s: date, %2$s: post title, %3$s: alt text. */
					__( '%1$s: added alt text to an image in "%2$s": "%3$s".', 'sourcefix' ),
					$date,
					$title,
					$fix->proposed_text
				);
			case SourceFix_Store::TYPE_LINK:
				return sprintf(
					/* translators: %1$s: date, %2$s: post title, %3$s: new link text. */
					__( '%1$s: improved a link text in "%2$s" to "%3$s".', 'sourcefix' ),
					$date,
					$title,
					$fix->proposed_text
				);
			case SourceFix_Store::TYPE_HEADING:
				return sprintf(
					/* translators: %1$s: date, %2$s: post title. */
					__( '%1$s: corrected the heading structure of "%2$s".', 'sourcefix' ),
					$date,
					$title
				);
			default:
				return sprintf(
					/* translators: %1$s: date, %2$s: post title. */
					__( '%1$s: applied a fix in "%2$s".', 'sourcefix' ),
					$date,
					$title
				);
		}
	}
}
