<?php
/**
 * Plan and licensing logic for SourceFix.
 *
 * SourceFix is sold through Freemius. The plans (unique names) are:
 *  - free    — Free, $0: 1 site, up to 50 AI fixes/month, approval queue,
 *              statement published once.
 *  - solo    — Solo, $79/yr: 1 site, unlimited authoring, auto-apply
 *              low-risk fixes, statement re-published on every change,
 *              12-month audit log.
 *  - studio  — Studio, $149/yr: 5 sites, plus per-site terminology memory.
 *  - agency  — Agency, $299/yr: 25 sites, plus agency dashboard and
 *              client reporting.
 *
 * The plan names and prices are configured in the Freemius Developer
 * Dashboard (see plugin/freemius-config.md). The Freemius product must be
 * registered there before the SDK can report a real plan; until then the
 * plugin runs as the Free tier and every feature below degrades safely.
 *
 * For testing a paid plan without a real purchase, the plan can be
 * overridden — but ONLY when the test-only file
 * `includes/test-overrides.php` is present in the plugin directory. That
 * file defines the SOURCEFIX_TEST_OVERRIDES constant and is NEVER shipped
 * (it must be excluded from the release zip and from the WordPress.org
 * submission). Without that file, the constant and the `sourcefix_plan`
 * filter below are dead code: no code on the site, including a
 * code-snippets plugin, can unlock a paid plan. A plan override requires
 * file access by design.
 *
 * @package SourceFix
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SourceFix_Licensing {

	/**
	 * Plan slugs.
	 */
	const PLAN_FREE   = 'free';
	const PLAN_SOLO   = 'solo';
	const PLAN_STUDIO = 'studio';
	const PLAN_AGENCY = 'agency';

	/**
	 * All plan slugs, lowest to highest.
	 *
	 * @var array
	 */
	private static $plans = array(
		self::PLAN_FREE,
		self::PLAN_SOLO,
		self::PLAN_STUDIO,
		self::PLAN_AGENCY,
	);

	/**
	 * Monthly AI-fix allowance on the Free plan.
	 */
	const FREE_MONTHLY_FIXES = 50;

	/**
	 * Audit log retention in days, by plan.
	 */
	const FREE_AUDIT_RETENTION_DAYS = 30;
	const PAID_AUDIT_RETENTION_DAYS = 365;

	/**
	 * Whether the Freemius SDK is initialized with a real product.
	 *
	 * @return bool
	 */
	public static function is_freemius_active() {
		return function_exists( 'sourcefix_fs' ) && sourcefix_fs() instanceof Freemius;
	}

	/**
	 * The current plan for this site.
	 *
	 * Test override (constant or filter) wins, then the Freemius plan,
	 * then Free. A paying plan that is not one of the known slugs is
	 * treated as Solo, the lowest paid tier.
	 *
	 * @return string One of free, solo, studio, agency.
	 */
	public static function current_plan() {
		// Test override — active ONLY when the test-only file
		// includes/test-overrides.php is present (it defines
		// SOURCEFIX_TEST_OVERRIDES). The shipped plugin never defines
		// that constant, so this block is dead code in production: the
		// constant in wp-config.php or the filter alone cannot unlock a
		// paid plan.
		if ( defined( 'SOURCEFIX_TEST_OVERRIDES' ) && SOURCEFIX_TEST_OVERRIDES ) {
			if ( defined( 'SOURCEFIX_PLAN_OVERRIDE' ) && is_string( SOURCEFIX_PLAN_OVERRIDE ) ) {
				$override = strtolower( trim( SOURCEFIX_PLAN_OVERRIDE ) );
				if ( in_array( $override, self::$plans, true ) ) {
					return $override;
				}
			}
			$filtered = apply_filters( 'sourcefix_plan', '' );
			if ( is_string( $filtered ) && in_array( strtolower( trim( $filtered ) ), self::$plans, true ) ) {
				return strtolower( trim( $filtered ) );
			}
		}

		if ( ! self::is_freemius_active() ) {
			return self::PLAN_FREE;
		}

		$fs = sourcefix_fs();
		if ( $fs->is_plan( self::PLAN_AGENCY, true ) ) {
			return self::PLAN_AGENCY;
		}
		if ( $fs->is_plan( self::PLAN_STUDIO, true ) ) {
			return self::PLAN_STUDIO;
		}
		if ( $fs->is_plan( self::PLAN_SOLO, true ) ) {
			return self::PLAN_SOLO;
		}
		// Paying (or trialling) but on an unknown plan: lowest paid tier.
		if ( $fs->is_paying_or_trial() ) {
			return self::PLAN_SOLO;
		}
		return self::PLAN_FREE;
	}

	/**
	 * Whether the current plan is a paid plan.
	 *
	 * @return bool
	 */
	public static function is_paid() {
		return self::PLAN_FREE !== self::current_plan();
	}

	/**
	 * Whether the current plan is at least the given plan.
	 *
	 * @param string $plan Plan slug.
	 * @return bool
	 */
	public static function is_at_least( $plan ) {
		$current = array_search( self::current_plan(), self::$plans, true );
		$wanted  = array_search( $plan, self::$plans, true );
		return false !== $current && false !== $wanted && $current >= $wanted;
	}

	/**
	 * Whether AI authoring is unlimited this month (paid plans only).
	 * The Free plan is capped at 50 AI fixes per month.
	 *
	 * @return bool
	 */
	public static function allows_unlimited_fixes() {
		return self::is_paid();
	}

	/**
	 * Whether low-risk fixes may be auto-applied (Solo and above).
	 *
	 * @return bool
	 */
	public static function allows_auto_apply() {
		return self::is_at_least( self::PLAN_SOLO );
	}

	/**
	 * Whether the public statement is re-published on every change
	 * (Solo and above). On Free it is published once, on activation.
	 *
	 * @return bool
	 */
	public static function allows_statement_republish() {
		return self::is_at_least( self::PLAN_SOLO );
	}

	/**
	 * Whether per-site terminology memory is available (Studio and above).
	 *
	 * @return bool
	 */
	public static function allows_terminology() {
		return self::is_at_least( self::PLAN_STUDIO );
	}

	/**
	 * Whether the agency dashboard and client reporting are available
	 * (Agency only).
	 *
	 * @return bool
	 */
	public static function allows_agency_dashboard() {
		return self::PLAN_AGENCY === self::current_plan();
	}

	/**
	 * Audit log retention in days for the current plan.
	 *
	 * @return int
	 */
	public static function audit_retention_days() {
		return self::is_paid() ? self::PAID_AUDIT_RETENTION_DAYS : self::FREE_AUDIT_RETENTION_DAYS;
	}

	/**
	 * Human-readable name of the current plan.
	 *
	 * @return string
	 */
	public static function plan_label() {
		switch ( self::current_plan() ) {
			case self::PLAN_SOLO:
				return __( 'Solo', 'sourcefix' );
			case self::PLAN_STUDIO:
				return __( 'Studio', 'sourcefix' );
			case self::PLAN_AGENCY:
				return __( 'Agency', 'sourcefix' );
			default:
				return __( 'Free', 'sourcefix' );
		}
	}

	/**
	 * URL the user can visit to upgrade. When Freemius is active this is
	 * the in-dashboard pricing page; otherwise it is the product site.
	 *
	 * @return string
	 */
	public static function upgrade_url() {
		if ( self::is_freemius_active() ) {
			return sourcefix_fs()->get_upgrade_url();
		}
		return 'https://usesourcefix.com/#pricing';
	}
}
