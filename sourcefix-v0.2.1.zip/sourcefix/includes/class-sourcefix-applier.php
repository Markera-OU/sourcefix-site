<?php
/**
 * Applies an approved fix to a post's content.
 *
 * - alt: sets the alt attribute on the image with the matching src.
 * - link: replaces the link text of the link with the matching href.
 * - heading: re-maps heading levels to the approved corrected structure.
 *
 * Applying a fix updates the post content, marks the fix applied, writes
 * an audit log entry, and refreshes the public statement's date.
 *
 * @package SourceFix
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SourceFix_Applier {

	/**
	 * Apply one fix by id. Returns true on success.
	 *
	 * @param int $fix_id Fix id.
	 * @return bool
	 */
	public static function apply_fix( $fix_id ) {
		$fix = SourceFix_Store::get_fix( $fix_id );
		if ( ! $fix ) {
			return false;
		}
		if ( SourceFix_Store::STATUS_APPLIED === $fix->status ) {
			return true;
		}

		$post = get_post( (int) $fix->post_id );
		if ( ! $post ) {
			return false;
		}

		$new_content = $post->post_content;
		switch ( $fix->field_type ) {
			case SourceFix_Store::TYPE_ALT:
				$new_content = self::apply_alt( $post->post_content, $fix->target, $fix->proposed_text );
				break;
			case SourceFix_Store::TYPE_LINK:
				$new_content = self::apply_link( $post->post_content, $fix->target, $fix->original_text, $fix->proposed_text );
				break;
			case SourceFix_Store::TYPE_HEADING:
				$new_content = self::apply_headings( $post->post_content, $fix->proposed_text );
				break;
			default:
				return false;
		}

		if ( null === $new_content || $new_content === $post->post_content ) {
			return false;
		}

		// Update the content without re-triggering the publish-time scan.
		remove_action( 'save_post', 'sourcefix_scan_on_save', 20 );
		$updated = wp_update_post(
			array(
				'ID'           => $post->ID,
				'post_content' => $new_content,
			),
			true
		);
		add_action( 'save_post', 'sourcefix_scan_on_save', 20, 3 );

		if ( is_wp_error( $updated ) || ! $updated ) {
			return false;
		}

		update_post_meta( $post->ID, '_sourcefix_content_hash', md5( $new_content ) );

		SourceFix_Store::set_fix_status( $fix_id, SourceFix_Store::STATUS_APPLIED );
		SourceFix_Store::audit_log(
			$post->ID,
			'fix_applied',
			self::audit_detail( $fix )
		);
		SourceFix_Statement::touch();

		return true;
	}

	/**
	 * Human-readable audit detail for a fix.
	 *
	 * @param object $fix Fix row.
	 * @return string
	 */
	private static function audit_detail( $fix ) {
		switch ( $fix->field_type ) {
			case SourceFix_Store::TYPE_ALT:
				if ( '' === $fix->proposed_text ) {
					return sprintf(
						/* translators: %s: image file name or URL. */
						__( 'Set empty alt text (decorative image) for %s.', 'sourcefix' ),
						$fix->target
					);
				}
				return sprintf(
					/* translators: %1$s: image URL, %2$s: alt text. */
					__( 'Set alt text for %1$s: "%2$s".', 'sourcefix' ),
					$fix->target,
					$fix->proposed_text
				);
			case SourceFix_Store::TYPE_LINK:
				return sprintf(
					/* translators: %1$s: link URL, %2$s: new link text. */
					__( 'Changed link text for %1$s to "%2$s".', 'sourcefix' ),
					$fix->target,
					$fix->proposed_text
				);
			case SourceFix_Store::TYPE_HEADING:
				return sprintf(
					/* translators: %s: post title. */
					__( 'Corrected the heading structure of "%s".', 'sourcefix' ),
					get_the_title( $fix->post_id )
				);
			default:
				return __( 'Applied a fix.', 'sourcefix' );
		}
	}

	/**
	 * Set the alt attribute on the image with the given src.
	 *
	 * @param string $content Post content.
	 * @param string $src     Image src to match.
	 * @param string $alt     Alt text to set (may be empty for decorative images).
	 * @return string|null New content, or null on failure.
	 */
	private static function apply_alt( $content, $src, $alt ) {
		$doc = self::load_html( $content );
		if ( ! $doc ) {
			return null;
		}
		$images  = $doc->getElementsByTagName( 'img' );
		$changed = false;
		foreach ( $images as $img ) {
			if ( $img->getAttribute( 'src' ) === $src && ! $img->hasAttribute( 'alt' ) ) {
				$img->setAttribute( 'alt', $alt );
				$changed = true;
				break;
			}
		}
		if ( ! $changed ) {
			return null;
		}
		return self::inner_html( $doc );
	}

	/**
	 * Replace the text of the link with the given href and original text.
	 *
	 * @param string $content   Post content.
	 * @param string $href      Link href to match.
	 * @param string $original  Original link text to match.
	 * @param string $proposed  New link text.
	 * @return string|null New content, or null on failure.
	 */
	private static function apply_link( $content, $href, $original, $proposed ) {
		$doc = self::load_html( $content );
		if ( ! $doc ) {
			return null;
		}
		$links   = $doc->getElementsByTagName( 'a' );
		$changed = false;
		foreach ( $links as $link ) {
			if ( $link->getAttribute( 'href' ) !== $href ) {
				continue;
			}
			$text = trim( preg_replace( '/\s+/', ' ', $link->textContent ) );
			if ( $text !== $original ) {
				continue;
			}
			// Replace the link's children with a single text node.
			while ( $link->firstChild ) {
				$link->removeChild( $link->firstChild );
			}
			$link->appendChild( $doc->createTextNode( $proposed ) );
			$changed = true;
			break;
		}
		if ( ! $changed ) {
			return null;
		}
		return self::inner_html( $doc );
	}

	/**
	 * Re-map heading levels to the approved corrected structure.
	 * The proposed text is headings, one per line, in "H1: ..."/"H2: ..."
	 * format, in the same order as the headings in the content.
	 *
	 * @param string $content  Post content.
	 * @param string $proposed Corrected headings, one per line.
	 * @return string|null New content, or null on failure.
	 */
	private static function apply_headings( $content, $proposed ) {
		$lines = array();
		foreach ( preg_split( '/\r\n|\r|\n/', $proposed ) as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}
			if ( preg_match( '/^H([1-6]):\s*(.*)$/i', $line, $m ) ) {
				$lines[] = array(
					'level' => (int) $m[1],
					'text'  => $m[2],
				);
			}
		}
		if ( empty( $lines ) ) {
			return null;
		}

		$doc = self::load_html( $content );
		if ( ! $doc ) {
			return null;
		}
		$xpath   = new DOMXPath( $doc );
		$nodes   = $xpath->query( '//h1|//h2|//h3|//h4|//h5|//h6' );
		$changed = false;
		$i       = 0;
		foreach ( $nodes as $node ) {
			if ( ! isset( $lines[ $i ] ) ) {
				break;
			}
			$new_level = $lines[ $i ]['level'];
			$old_level = (int) substr( strtolower( $node->tagName ), 1 );
			if ( $new_level !== $old_level ) {
				$new_node = $doc->createElement( 'h' . $new_level );
				while ( $node->firstChild ) {
					$new_node->appendChild( $node->firstChild );
				}
				foreach ( $node->attributes as $attr ) {
					$new_node->setAttribute( $attr->nodeName, $attr->nodeValue );
				}
				$node->parentNode->replaceChild( $new_node, $node );
				$changed = true;
			}
			$i++;
		}
		if ( ! $changed ) {
			return null;
		}
		return self::inner_html( $doc );
	}

	/**
	 * Load content into a DOMDocument.
	 *
	 * @param string $html Post content.
	 * @return DOMDocument|null
	 */
	private static function load_html( $html ) {
		if ( ! class_exists( 'DOMDocument' ) ) {
			return null;
		}
		$doc  = new DOMDocument();
		$prev = libxml_use_internal_errors( true );
		$doc->loadHTML( '<?xml encoding="utf-8" ?><!DOCTYPE html><html><body>' . $html . '</body></html>' );
		libxml_clear_errors();
		libxml_use_internal_errors( $prev );
		return $doc;
	}

	/**
	 * Get the inner HTML of the body element (the original content,
	 * with edits applied).
	 *
	 * @param DOMDocument $doc Parsed document.
	 * @return string
	 */
	private static function inner_html( $doc ) {
		$body = $doc->getElementsByTagName( 'body' )->item( 0 );
		if ( ! $body ) {
			return '';
		}
		$html = '';
		foreach ( $body->childNodes as $child ) {
			$html .= $doc->saveHTML( $child );
		}
		return $html;
	}
}
