<?php
/**
 * Client for the SourceFix backend API (the AI authoring service).
 *
 * All calls are best-effort: on any failure the method returns null and
 * logs the failure. A backend outage must never break publishing.
 *
 * @package SourceFix
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SourceFix_API {

	/**
	 * Get the configured backend API base URL.
	 *
	 * @return string
	 */
	public static function base_url() {
		$url = get_option( 'sourcefix_api_url', SOURCEFIX_API_URL );
		return rtrim( trim( $url ), '/' );
	}

	/**
	 * The site's backend API key, if this site has registered.
	 *
	 * @return string
	 */
	public static function site_key() {
		return (string) get_option( 'sourcefix_site_key', '' );
	}

	/**
	 * Make sure this site is registered with the backend and has an API
	 * key. Registration is idempotent server-side: re-registering an
	 * existing site URL rotates the key, which is also how a site
	 * recovers from a lost key. Best-effort: returns null when the
	 * backend cannot be reached, and the caller must degrade gracefully
	 * (authoring is skipped, the fix queues as manual).
	 *
	 * @return string|null The API key, or null when registration failed.
	 */
	public static function ensure_registered() {
		$key = self::site_key();
		if ( '' !== $key ) {
			return $key;
		}

		$response = self::post_raw(
			'/api/register',
			array(
				'site_url' => home_url(),
				'plan'     => SourceFix_Licensing::current_plan(),
			),
			array()
		);
		if ( null === $response || ! isset( $response['api_key'] ) ) {
			return null;
		}
		update_option( 'sourcefix_site_key', sanitize_text_field( $response['api_key'] ) );
		if ( isset( $response['plan'] ) ) {
			update_option( 'sourcefix_registered_plan', sanitize_key( $response['plan'] ) );
		}
		return (string) $response['api_key'];
	}

	/**
	 * Tell the backend when this site's plan changed (e.g. the owner
	 * bought Solo). Best-effort; the backend keeps enforcing the last
	 * plan it knows until the sync succeeds.
	 */
	public static function maybe_sync_plan() {
		$key = self::site_key();
		if ( '' === $key ) {
			return;
		}
		$current    = SourceFix_Licensing::current_plan();
		$registered = get_option( 'sourcefix_registered_plan', '' );
		if ( $current === $registered ) {
			return;
		}
		$response = self::post_raw(
			'/api/sites/me/plan',
			array( 'plan' => $current ),
			array( 'Authorization' => 'Bearer ' . $key )
		);
		if ( null !== $response && isset( $response['plan'] ) ) {
			update_option( 'sourcefix_registered_plan', sanitize_key( $response['plan'] ) );
		}
	}

	/**
	 * Author alt text for one image.
	 *
	 * @param array $args page_language, image_role, surrounding_copy, product_name.
	 * @return string|null The alt text, or null on failure.
	 */
	public static function author_alt( $args ) {
		$body = array(
			'page_language'   => isset( $args['page_language'] ) ? $args['page_language'] : get_locale(),
			'image_role'      => isset( $args['image_role'] ) ? $args['image_role'] : 'informative',
			'surrounding_copy' => isset( $args['surrounding_copy'] ) ? $args['surrounding_copy'] : '',
			'product_name'    => isset( $args['product_name'] ) ? $args['product_name'] : '',
		);

		$response = self::post( '/api/author-alt', $body );
		if ( null === $response || ! isset( $response['alt_text'] ) ) {
			return null;
		}
		$text = trim( (string) $response['alt_text'] );
		return '' === $text ? null : $text;
	}

	/**
	 * Fix a heading structure. Input and output are headings, one per line,
	 * in "H1: ..."/"H2: ..." format.
	 *
	 * @param string $headings Headings, one per line, in order.
	 * @return string|null The corrected headings, or null on failure.
	 */
	public static function fix_headings( $headings ) {
		$response = self::post( '/api/author-headings', array( 'headings' => $headings ) );
		if ( null === $response || ! isset( $response['headings'] ) ) {
			return null;
		}
		$text = trim( (string) $response['headings'] );
		return '' === $text ? null : $text;
	}

	/**
	 * POST a JSON body to the backend and decode the JSON response.
	 *
	 * Adds this site's API key as a Bearer token (registering first when
	 * the site has none). A 401 means the stored key is no longer valid:
	 * the key is cleared and registration is retried once (server-side
	 * re-registration rotates the key). A transport failure (no HTTP
	 * response at all) is retried once: authoring is idempotent. A 429
	 * means the Free monthly cap or a rate limit was hit server-side:
	 * the call is skipped and the fix queues as manual, exactly like
	 * any other API failure.
	 *
	 * @param string $path API path, e.g. /api/author-alt.
	 * @param array  $body Request body.
	 * @return array|null Decoded response, or null on any failure.
	 */
	private static function post( $path, $body ) {
		$key = self::ensure_registered();
		if ( null === $key ) {
			// Registration failed (backend unreachable). Never break
			// publishing for this: the caller queues a manual fix.
			return null;
		}
		self::maybe_sync_plan();

		$response = self::post_raw(
			$path,
			$body,
			array( 'Authorization' => 'Bearer ' . $key )
		);
		if ( null !== $response ) {
			return $response;
		}

		// Transport failure (last_status 0: the request never got an
		// HTTP response, e.g. the connection was reset in transit) is
		// worth one retry: authoring is idempotent, and the backend
		// usually completed the first attempt, so the retry is cheap.
		// Observed live 2026-11-11: the backend logs the call as ok
		// while the WP HTTP client sees "Empty reply from server" on
		// roughly 1 in 3-4 calls; a retry recovers those. Do NOT retry
		// real HTTP statuses: 429 is the cap/rate limit, 500 is a
		// server error that a fast retry would only repeat.
		if ( 0 === self::$last_status ) {
			$response = self::post_raw(
				$path,
				$body,
				array( 'Authorization' => 'Bearer ' . $key )
			);
			if ( null !== $response ) {
				return $response;
			}
		}

		// post_raw returns null on any non-200, including 401. If the
		// key was rejected, clear it and try once with a fresh key.
		if ( 401 === self::$last_status ) {
			delete_option( 'sourcefix_site_key' );
			delete_option( 'sourcefix_registered_plan' );
			$key = self::ensure_registered();
			if ( null === $key ) {
				return null;
			}
			return self::post_raw(
				$path,
				$body,
				array( 'Authorization' => 'Bearer ' . $key )
			);
		}
		return null;
	}

	/**
	 * Last HTTP status seen by post_raw (0 when the request itself
	 * failed). Lets post() distinguish a rejected key (401) from other
	 * failures without re-issuing the request.
	 *
	 * @var int
	 */
	private static $last_status = 0;

	/**
	 * Low-level POST: one request, extra headers as given, no auth
	 * handling and no retry. Used by post() and by registration itself.
	 *
	 * @param string $path    API path, e.g. /api/author-alt.
	 * @param array  $body    Request body.
	 * @param array  $headers Extra headers.
	 * @return array|null Decoded response, or null on any failure.
	 */
	private static function post_raw( $path, $body, $headers ) {
		$url = self::base_url() . $path;

		$response = wp_remote_post(
			$url,
			array(
				'method'  => 'POST',
				// Keep the timeout short enough that a dead backend does not
				// hang publishing: the authoring service normally answers
				// in a few seconds.
				'timeout' => 30,
				'headers' => array_merge(
					array(
						'Content-Type' => 'application/json',
						'Accept'       => 'application/json',
					),
					$headers
				),
				'body'    => wp_json_encode( $body ),
			)
		);

		if ( is_wp_error( $response ) ) {
			self::$last_status = 0;
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			error_log( 'SourceFix: API request to ' . $path . ' failed: ' . $response->get_error_message() );
			return null;
		}

		$code              = (int) wp_remote_retrieve_response_code( $response );
		self::$last_status = $code;
		$raw               = wp_remote_retrieve_body( $response );
		if ( 200 !== $code && 201 !== $code ) {
			// 429 (cap / rate limit) is an expected, non-error outcome:
			// log it briefly and let the caller queue a manual fix.
			// Other statuses get the same treatment with the body
			// truncated; the detail stays in the log, not in the UI.
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			error_log( 'SourceFix: API request to ' . $path . ' returned HTTP ' . $code . ': ' . substr( $raw, 0, 300 ) );
			return null;
		}

		$data = json_decode( $raw, true );
		if ( ! is_array( $data ) ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			error_log( 'SourceFix: API request to ' . $path . ' returned non-JSON output.' );
			return null;
		}
		return $data;
	}
}
