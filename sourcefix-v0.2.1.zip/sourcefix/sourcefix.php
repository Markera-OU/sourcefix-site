<?php
/**
 * Plugin Name:       SourceFix
 * Plugin URI:        https://usesourcefix.com
 * Description:       AI-assisted accessibility fixes at publish time. SourceFix scans new and updated posts for images missing alt text, poor link text, and heading structure issues, authors fixes with AI, and keeps an approval queue so you stay in control. A dated statement records what was fixed.
 * Version:           0.2.1
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Markera OÜ
 * Author URI:        https://markera.co
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       sourcefix
 * Domain Path:       /languages
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SOURCEFIX_VERSION', '0.2.1' );
define( 'SOURCEFIX_PLUGIN_FILE', __FILE__ );
define( 'SOURCEFIX_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SOURCEFIX_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
// Default backend API URL. The admin can override it on the settings page.
define( 'SOURCEFIX_API_URL', 'https://backend-production-2abf.up.railway.app' );
// Free tier: AI-authored fixes per calendar month.
define( 'SOURCEFIX_FREE_MONTHLY_FIXES', 50 );

/**
 * Freemius product credentials.
 *
 * Fill these in after creating the product in the Freemius Developer
 * Dashboard (see plugin/freemius-config.md for the exact steps). The
 * public key is not secret; the secret key is never stored in this repo.
 * Until the product is registered, the plugin runs as the Free tier and
 * the Freemius SDK is not loaded.
 */
define( 'SOURCEFIX_FS_ID', 44509 );
define( 'SOURCEFIX_FS_PUBLIC_KEY', 'pk_f5a97fb9fdac57c555b57729f963e' );

/**
 * Initialize the Freemius SDK.
 *
 * Guarded: when the product is not registered yet (ID/key empty), the
 * SDK is skipped and the plugin behaves as the Free tier. The array is
 * passed literally to fs_dynamic_init, as Freemius requires.
 */
if ( ! function_exists( 'sourcefix_fs' ) ) {
	function sourcefix_fs() {
		global $sourcefix_fs;
		if ( ! isset( $sourcefix_fs ) ) {
			if ( SOURCEFIX_FS_ID && '' !== SOURCEFIX_FS_PUBLIC_KEY ) {
				require_once SOURCEFIX_PLUGIN_DIR . 'freemius/start.php';
				$sourcefix_fs = fs_dynamic_init(
					array(
						'id'                  => SOURCEFIX_FS_ID,
						'slug'                => 'sourcefix',
						'type'                => 'plugin',
						'public_key'          => SOURCEFIX_FS_PUBLIC_KEY,
						'is_premium'          => false,
						'has_premium_version' => true,
						'has_paid_plans'      => true,
						'is_org_compliant'    => true,
						'menu'                => array(
							'slug'    => 'sourcefix',
							'account' => true,
							'pricing' => true,
							'support' => true,
							'contact' => true,
						),
					)
				);
			} else {
				$sourcefix_fs = null;
			}
		}
		return $sourcefix_fs;
	}
	sourcefix_fs();
	do_action( 'sourcefix_fs_loaded' );
}

require_once SOURCEFIX_PLUGIN_DIR . 'includes/class-sourcefix-licensing.php';
require_once SOURCEFIX_PLUGIN_DIR . 'includes/class-sourcefix-store.php';
require_once SOURCEFIX_PLUGIN_DIR . 'includes/class-sourcefix-api.php';

// Test-only paid-plan overrides. The file is NEVER shipped (it must be
// excluded from the release zip and the WordPress.org submission); when
// it is absent, the override block in current_plan() is dead code and
// no code on the site can unlock a paid plan.
if ( file_exists( SOURCEFIX_PLUGIN_DIR . 'includes/test-overrides.php' ) ) {
	require_once SOURCEFIX_PLUGIN_DIR . 'includes/test-overrides.php';
}
require_once SOURCEFIX_PLUGIN_DIR . 'includes/class-sourcefix-scanner.php';
require_once SOURCEFIX_PLUGIN_DIR . 'includes/class-sourcefix-applier.php';
require_once SOURCEFIX_PLUGIN_DIR . 'includes/class-sourcefix-statement.php';
require_once SOURCEFIX_PLUGIN_DIR . 'admin/class-sourcefix-admin.php';

/**
 * Activation: create the database tables, set defaults, create the
 * statement page, and record the activation in the audit log.
 */
function sourcefix_activate() {
	SourceFix_Store::create_tables();

	add_option( 'sourcefix_api_url', SOURCEFIX_API_URL );
	add_option( 'sourcefix_auto_apply', '1' );
	add_option( 'sourcefix_month_key', gmdate( 'Y-m' ) );
	add_option( 'sourcefix_month_count', 0 );

	// Register this site with the backend and store its API key. The
	// backend requires a key for every authoring call; registration is
	// best-effort here (a failed registration is retried lazily on the
	// first API call) and must never break activation.
	SourceFix_API::ensure_registered();

	SourceFix_Statement::maybe_create_page();

	// Daily maintenance: prune the audit log to the plan's retention
	// (Free: 30 days, paid: 12 months).
	if ( ! wp_next_scheduled( 'sourcefix_daily_maintenance' ) ) {
		wp_schedule_event( time(), 'daily', 'sourcefix_daily_maintenance' );
	}

	SourceFix_Store::audit_log( 0, 'plugin_activated', __( 'SourceFix activated.', 'sourcefix' ) );
}
register_activation_hook( __FILE__, 'sourcefix_activate' );

/**
 * Deactivation: nothing destructive. Tables and options stay so a
 * re-activation keeps the approval history. The maintenance cron is
 * cleared; it is re-registered on the next activation.
 */
function sourcefix_deactivate() {
	wp_clear_scheduled_hook( 'sourcefix_daily_maintenance' );
	SourceFix_Store::audit_log( 0, 'plugin_deactivated', __( 'SourceFix deactivated.', 'sourcefix' ) );
}
register_deactivation_hook( __FILE__, 'sourcefix_deactivate' );

/**
 * Daily maintenance: prune the audit log to the current plan's retention.
 */
function sourcefix_daily_maintenance() {
	$deleted = SourceFix_Store::prune_audit_log( SourceFix_Licensing::audit_retention_days() );
	if ( $deleted > 0 ) {
		SourceFix_Store::audit_log( 0, 'audit_pruned', sprintf( __( 'Removed %d audit log entries older than the plan retention.', 'sourcefix' ), $deleted ) );
	}
}
add_action( 'sourcefix_daily_maintenance', 'sourcefix_daily_maintenance' );

/**
 * Publish-time scan. Runs when a post or page is saved as published (new
 * publish or an update). Autosaves, revisions, and non-public post types
 * are skipped. API failures are logged and never break publishing.
 *
 * @param int     $post_id Post ID.
 * @param WP_Post $post    Post object.
 * @param bool    $update  Whether this is an update.
 */
function sourcefix_scan_on_save( $post_id, $post, $update ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
		return;
	}
	if ( 'publish' !== $post->post_status ) {
		return;
	}
	if ( ! in_array( $post->post_type, array( 'post', 'page' ), true ) ) {
		return;
	}
	// Only scan when the content actually changed on an update.
	if ( $update ) {
		$old = get_post_meta( $post_id, '_sourcefix_content_hash', true );
		$new = md5( $post->post_content );
		if ( $old === $new ) {
			return;
		}
		update_post_meta( $post_id, '_sourcefix_content_hash', md5( $post->post_content ) );
	} else {
		update_post_meta( $post_id, '_sourcefix_content_hash', md5( $post->post_content ) );
	}

	SourceFix_Scanner::scan_post( $post_id, $post );
}
add_action( 'save_post', 'sourcefix_scan_on_save', 20, 3 );

/**
 * Load translations.
 */
function sourcefix_load_textdomain() {
	load_plugin_textdomain( 'sourcefix', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
add_action( 'init', 'sourcefix_load_textdomain' );

/**
 * Register the admin screens and the public statement shortcode.
 */
function sourcefix_init() {
	SourceFix_Admin::init();
	SourceFix_Statement::init();
}
add_action( 'init', 'sourcefix_init' );
