<?php
/**
 * Uninstall SourceFix: remove the plugin's tables and options.
 *
 * @package SourceFix
 */

// Exit if accessed directly.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'sourcefix_fixes' );
$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'sourcefix_audit' );

delete_option( 'sourcefix_api_url' );
delete_option( 'sourcefix_site_key' );
delete_option( 'sourcefix_registered_plan' );
delete_option( 'sourcefix_auto_apply' );
delete_option( 'sourcefix_month_key' );
delete_option( 'sourcefix_month_count' );
delete_option( 'sourcefix_statement_page_id' );
delete_option( 'sourcefix_statement_updated' );
delete_option( 'sourcefix_terminology' );
delete_post_meta_by_key( '_sourcefix_content_hash' );

wp_clear_scheduled_hook( 'sourcefix_daily_maintenance' );
