=== SourceFix ===
Contributors: sourcefix
Donate link: https://usesourcefix.com
Tags: accessibility, alt text, headings, link text, ai
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 0.2.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI-assisted accessibility fixes at publish time: alt text, link text, and heading structure, with an approval queue and a dated public statement.

== Description ==

SourceFix scans your posts and pages when they are published or updated and finds three common accessibility issues:

* Images missing alt text
* Links with poor link text ("click here", "read more", bare URLs)
* Heading structure problems (missing H1, multiple H1s, skipped levels)

For images and headings, SourceFix asks its AI authoring service to write a fix. Low-risk alt text fixes are applied automatically when the context is clear; everything else goes to an approval queue where you review, edit, and approve or reject each fix with one click. Every fix that is applied is written to an audit log, and a dated public statement page lists what was fixed and when.

SourceFix does not claim your site complies with any accessibility standard. The statement it publishes describes the fixes that were applied; it is a record of work done, not a compliance claim.

= What the free version includes =

* Publish-time scanning for posts and pages
* AI-authored alt text and heading fixes (up to 50 AI fixes per month)
* Approval queue with one-click approve and reject, and editable proposed text
* Audit log of every fix applied (kept 30 days)
* Dated public accessibility statement page (published once)

= Paid plans =

* Solo ($79/year, 1 site): unlimited AI-authored fixes, automatic application of low-risk alt text fixes, statement re-published on every change, 12-month audit log.
* Studio ($149/year, 5 sites): everything in Solo, plus per-site terminology memory so the AI writes fixes in your site's own words.
* Agency ($299/year, 25 sites): everything in Studio, plus an agency dashboard and downloadable client reports.

Billing is handled by Freemius. You can upgrade from the Settings page.

= How it works =

1. Publish or update a post or page.
2. SourceFix scans the content and, where needed, asks the AI authoring service for a fix.
3. Low-risk alt text fixes are applied automatically. Other fixes wait in the Fix Queue for your approval.
4. The public statement page is re-dated every time a fix is applied.

= Privacy =

SourceFix sends the text around an image and the list of headings on a page to its AI authoring service (hosted at backend-production-2abf.up.railway.app) so the service can write alt text and correct heading structure. No other content is sent, and nothing is tracked. The service stores per-site approval history (which fixes were approved or rejected) so future suggestions can learn from your choices.

== Installation ==

1. Download the plugin zip from https://usesourcefix.com/sourcefix-v0.2.1.zip.
2. In WordPress, go to Plugins > Add New > Upload Plugin, choose the zip, and activate it. Or unzip the `sourcefix` folder into `/wp-content/plugins/` and activate it.
3. On activation, SourceFix creates a page called "Accessibility Statement" and adds a Fix Queue, Audit Log, and Settings under the SourceFix menu. It registers this site with the authoring service automatically; no key to copy.
4. Publish or update a post to see the first scan results.

The WordPress.org listing is pending review, so the directory install is not available yet. Once it is live, you will also be able to install SourceFix from Plugins > Add New by searching for "SourceFix".

== Frequently Asked Questions ==

= Does SourceFix make my site compliant with WCAG or the European Accessibility Act? =

No. SourceFix finds and fixes common issues, and records what it fixed. It does not claim compliance with WCAG, the EAA, or any other standard, and it does not audit your whole site.

= What happens if the AI service is unavailable? =

Publishing is never blocked. Issues are still detected and queued for manual review, and the failure is logged.

= Can I turn off automatic fixes? =

Yes. Settings has an "Auto-apply low-risk fixes" checkbox. With it off, every fix waits in the queue for your approval.

= What counts as a low-risk fix? =

Alt text for an informative image where the surrounding copy gives clear context and the AI returned a confident, non-empty result. Decorative images get an empty alt attribute, which is also applied automatically. Heading and link fixes always go to the queue.

== Screenshots ==

1. The Fix Queue, with proposed fixes ready to approve or reject.
2. The Settings page.
3. The public accessibility statement.

== Changelog ==

= 0.2.1 =
* The authoring service now requires a per-site API key: the plugin registers this site on activation and sends the key with every authoring request. The Free 50-fix monthly cap is enforced server-side. Version 0.2.0 can no longer author fixes against the service, so please update to 0.2.1.
* Paid-plan overrides are test-only now: without the test file, no code on the site can unlock a paid plan.

= 0.2.0 =
* Freemius billing: Free, Solo ($79/year), Studio ($149/year), and Agency ($299/year) plans. Free is capped at 50 AI fixes per month; paid plans have unlimited authoring. Auto-apply, statement re-publishing, and the 12-month audit log are Solo and above; terminology memory is Studio and above; the agency dashboard and client reports are Agency only.
* Dated public statement is published once on the Free plan and re-published on every change on paid plans.

= 0.1.0 =
* First release: publish-time scanning, AI-authored alt text and heading fixes, approval queue, audit log, dated public statement.

== Upgrade Notice ==

= 0.2.1 =
* Required update: the authoring service now requires a per-site API key, which 0.2.1 registers automatically. Version 0.2.0 can no longer author fixes.

= 0.2.0 =
* Freemius billing and plan-gated features. Free-plan behaviour is unchanged apart from auto-apply, which is now a Solo feature: on Free, every fix waits in the approval queue.

= 0.1.0 =
* First release.
