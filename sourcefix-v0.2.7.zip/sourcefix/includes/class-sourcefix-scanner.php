<?php
/**
 * Publish-time scanner.
 *
 * Parses a post's content and finds three kinds of issues:
 *  - images missing alt text,
 *  - links with poor link text ("click here", "read more", bare URLs),
 *  - heading structure problems (no H1, multiple H1s, skipped levels).
 *
 * For images it asks the backend API to author alt text. Low-risk fixes
 * are auto-applied when the setting allows it; everything else goes to
 * the approval queue. The backend is never allowed to break publishing:
 * any API failure is logged and the issue is queued for manual review.
 *
 * @package SourceFix
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SourceFix_Scanner {

	/**
	 * Generic link text that tells the reader nothing about the destination.
	 */
	private static $generic_link_text = array(
		'click here',
		'click',
		'here',
		'link',
		'more',
		'read more',
		'learn more',
		'find out more',
		'this',
		'download',
		'go',
		'continue',
		'continue reading',
	);

	/**
	 * Scan a published post and handle the issues found.
	 *
	 * @param int      $post_id          Post ID.
	 * @param WP_Post  $post             Post object.
	 * @param bool     $allow_auto_apply Whether low-risk fixes may be
	 *                                   auto-applied. The re-scan after
	 *                                   an apply (audit H-8) passes
	 *                                   false: it only queues what is
	 *                                   still wrong.
	 */
	public static function scan_post( $post_id, $post, $allow_auto_apply = true ) {
		$doc = self::load_html( $post->post_content );
		if ( ! $doc ) {
			return;
		}

		$auto_apply = $allow_auto_apply
			&& SourceFix_Licensing::allows_auto_apply()
			&& '1' === get_option( 'sourcefix_auto_apply', '1' );
		$issues     = 0;

		$issues += self::scan_images( $post_id, $post, $doc, $auto_apply );
		$issues += self::scan_links( $post_id, $post, $doc );
		$issues += self::scan_headings( $post_id, $post, $doc );

		if ( $issues > 0 ) {
			SourceFix_Store::audit_log(
				$post_id,
				'scan',
				sprintf(
					/* translators: %d: number of issues found. */
					__( 'Scan found %d issue(s) in this post.', 'sourcefix' ),
					$issues
				)
			);
		}
	}

	/**
	 * Load post content into a DOMDocument.
	 *
	 * @param string $html Post content.
	 * @return DOMDocument|null
	 */
	private static function load_html( $html ) {
		if ( ! class_exists( 'DOMDocument' ) ) {
			return null;
		}
		$doc = new DOMDocument();
		$prev = libxml_use_internal_errors( true );
		// The XML prolog forces UTF-8 parsing; the wrapper keeps fragments valid.
		$doc->loadHTML( '<?xml encoding="utf-8" ?><!DOCTYPE html><html><body>' . $html . '</body></html>' );
		libxml_clear_errors();
		libxml_use_internal_errors( $prev );
		return $doc;
	}

	/**
	 * Scan images for missing alt text.
	 *
	 * @param int          $post_id    Post ID.
	 * @param WP_Post      $post       Post object.
	 * @param DOMDocument  $doc        Parsed content.
	 * @param bool         $auto_apply Whether auto-apply is enabled.
	 * @return int Number of issues found.
	 */
	private static function scan_images( $post_id, $post, $doc, $auto_apply ) {
		$images = $doc->getElementsByTagName( 'img' );

		// Audit H-8: occurrence per src, counted among ALL images with
		// that src in document order (not only the ones still missing
		// alt text), so the number stays stable as earlier occurrences
		// get fixed. Pre-counted here because the DOMNodeList is
		// walked twice below.
		$occurrence_by_index = array();
		$seen_src            = array();
		for ( $i = 0; $i < $images->length; $i++ ) {
			$src = $images->item( $i )->getAttribute( 'src' );
			if ( '' === $src ) {
				$occurrence_by_index[ $i ] = 0;
				continue;
			}
			$seen_src[ $src ] = isset( $seen_src[ $src ] ) ? $seen_src[ $src ] + 1 : 1;
			$occurrence_by_index[ $i ] = $seen_src[ $src ];
		}

		$count = 0;
		$index = 0;

		foreach ( $images as $img ) {
			$occurrence = isset( $occurrence_by_index[ $index ] ) ? $occurrence_by_index[ $index ] : 1;
			$index++;
			if ( $img->hasAttribute( 'alt' ) ) {
				continue;
			}
			$src = $img->getAttribute( 'src' );
			if ( '' === $src ) {
				continue;
			}
			$count++;

			$role = self::image_role( $img );
			$copy = self::surrounding_copy( $img );
			// The safety check below measures the real surrounding
			// context, so keep it before terminology is prepended:
			// terminology alone must not green-light auto-apply on a
			// context-free image.
			$context = $copy;
			// Studio and above: include the site's terminology so the AI
			// writes alt text in the site's own words.
			if ( SourceFix_Licensing::allows_terminology() ) {
				$terms = SourceFix_Store::terminology_context();
				if ( '' !== $terms ) {
					$copy = $terms . ' ' . $copy;
				}
			}

			if ( 'decorative' === $role ) {
				// Decorative images get an empty alt attribute. No AI call
				// needed, and it is safe to apply automatically.
				$fix_id = SourceFix_Store::add_fix(
					$post_id,
					SourceFix_Store::TYPE_ALT,
					$src,
					'',
					'',
					'ai',
					$occurrence
				);
				if ( $auto_apply && $fix_id ) {
					SourceFix_Applier::apply_fix( $fix_id );
				}
				continue;
			}

			// Informative image: author alt text with the backend.
			// Paid plans have unlimited AI fixes; the Free plan is capped
			// at 50 per month.
			//
			// Audit H-8: when this exact element already has a pending
			// fix with a real proposal (e.g. this is the re-scan after
			// an apply, or a re-publish), reuse it instead of spending
			// another AI call and another cap unit on the same fix.
			$alt = null;
			$existing = method_exists( 'SourceFix_Store', 'find_pending_fix' )
				? SourceFix_Store::find_pending_fix( $post_id, SourceFix_Store::TYPE_ALT, $src, $occurrence )
				: null;
			if ( $existing && '' !== $existing->proposed_text ) {
				$alt = $existing->proposed_text;
			} elseif ( SourceFix_Licensing::allows_unlimited_fixes() || ! SourceFix_Store::monthly_cap_reached() ) {
				$alt = SourceFix_API::author_alt(
					array(
						'page_language'    => get_locale(),
						'image_role'       => 'informative',
						'surrounding_copy' => $copy,
						'product_name'     => '',
					)
				);
				if ( null !== $alt ) {
					SourceFix_Store::increment_monthly_fix_count();
				}
			}

			$fix_id = SourceFix_Store::add_fix(
				$post_id,
				SourceFix_Store::TYPE_ALT,
				$src,
				'',
				null === $alt ? '' : $alt,
				null === $alt ? 'manual' : 'ai',
				$occurrence
			);

			// Auto-apply only low-risk fixes: the model returned a real,
			// non-empty result, the surrounding copy gives clear context,
			// and the result does not look like a filename or a generic
			// "image of" phrase.
			if ( $auto_apply && $fix_id && null !== $alt && self::alt_is_safe_to_auto_apply( $alt, $context, $src ) ) {
				SourceFix_Applier::apply_fix( $fix_id );
			}
		}

		return $count;
	}

	/**
	 * Decide whether an image is decorative.
	 *
	 * @param DOMElement $img Image element.
	 * @return string decorative or informative.
	 */
	private static function image_role( $img ) {
		if ( 'presentation' === $img->getAttribute( 'role' ) || 'true' === $img->getAttribute( 'aria-hidden' ) ) {
			return 'decorative';
		}
		$src = strtolower( $img->getAttribute( 'src' ) );
		$cls = strtolower( $img->getAttribute( 'class' ) );
		if ( false !== strpos( $src, 'spacer' ) || false !== strpos( $src, 'pixel' ) || false !== strpos( $src, 'tracking' ) ) {
			return 'decorative';
		}
		if ( false !== strpos( $cls, 'spacer' ) || false !== strpos( $cls, 'tracking-pixel' ) ) {
			return 'decorative';
		}
		$width  = (int) $img->getAttribute( 'width' );
		$height = (int) $img->getAttribute( 'height' );
		if ( $width > 0 && $height > 0 && $width <= 1 && $height <= 1 ) {
			return 'decorative';
		}
		return 'informative';
	}

	/**
	 * Get the text around an image, for the authoring prompt. Prefers the
	 * text of the nearest block ancestor; when the image sits alone in its
	 * own block, falls back to the nearest preceding and following sibling
	 * blocks so the model still has context to describe the image.
	 *
	 * @param DOMElement $img Image element.
	 * @return string
	 */
	private static function surrounding_copy( $img ) {
		$node = $img->parentNode;
		while ( $node && $node instanceof DOMElement ) {
			$tag = strtolower( $node->tagName );
			if ( in_array( $tag, array( 'p', 'figure', 'div', 'li', 'td', 'figcaption' ), true ) ) {
				$text = trim( preg_replace( '/\s+/', ' ', $node->textContent ) );
				if ( '' !== $text ) {
					return mb_substr( $text, 0, 500 );
				}
				// The image is alone in its block: use nearby sibling blocks.
				$nearby = self::sibling_copy( $node );
				if ( '' !== $nearby ) {
					return mb_substr( $nearby, 0, 500 );
				}
			}
			$node = $node->parentNode;
		}
		return '';
	}

	/**
	 * Text from the nearest preceding and following sibling blocks.
	 *
	 * @param DOMElement $block The block containing the image.
	 * @return string
	 */
	private static function sibling_copy( $block ) {
		$parts = array();
		$prev  = $block->previousSibling;
		while ( $prev && count( $parts ) < 1 ) {
			if ( $prev instanceof DOMElement ) {
				$text = trim( preg_replace( '/\s+/', ' ', $prev->textContent ) );
				if ( '' !== $text ) {
					$parts[] = $text;
				}
			}
			$prev = $prev->previousSibling;
		}
		$next = $block->nextSibling;
		while ( $next && count( $parts ) < 2 ) {
			if ( $next instanceof DOMElement ) {
				$text = trim( preg_replace( '/\s+/', ' ', $next->textContent ) );
				if ( '' !== $text ) {
					$parts[] = $text;
				}
			}
			$next = $next->nextSibling;
		}
		return implode( ' ', $parts );
	}

	/**
	 * Conservative check for auto-applying an AI-authored alt text.
	 *
	 * @param string $alt  The authored alt text.
	 * @param string $copy Surrounding copy.
	 * @param string $src  Image src.
	 * @return bool
	 */
	private static function alt_is_safe_to_auto_apply( $alt, $copy, $src ) {
		if ( '' === $alt ) {
			return false;
		}
		// Clear context is required: at least a short sentence around it.
		if ( mb_strlen( $copy ) < 20 ) {
			return false;
		}
		// Reject results that just repeat the file name.
		$filename = strtolower( pathinfo( wp_parse_url( $src, PHP_URL_PATH ), PATHINFO_FILENAME ) );
		$filename = str_replace( array( '-', '_' ), ' ', $filename );
		if ( '' !== $filename && strtolower( $alt ) === $filename ) {
			return false;
		}
		// Reject generic "image of" phrasing and keyword-stuffed results.
		if ( preg_match( '/^(an?\s+)?(image|picture|photo)\s+of\b/i', $alt ) ) {
			return false;
		}
		// Reject placeholder results ("description unavailable" and friends).
		if ( preg_match( '/\b(description|alt text|image)\s+(unavailable|not available|missing)\b/i', $alt ) ) {
			return false;
		}
		if ( mb_strlen( $alt ) > 250 ) {
			return false;
		}
		return true;
	}

	/**
	 * Scan links for poor link text.
	 *
	 * @param int         $post_id Post ID.
	 * @param WP_Post     $post    Post object.
	 * @param DOMDocument $doc     Parsed content.
	 * @return int Number of issues found.
	 */
	private static function scan_links( $post_id, $post, $doc ) {
		$links = $doc->getElementsByTagName( 'a' );

		// Audit H-8: occurrence per href, counted among ALL links
		// with that href in document order, so the number stays
		// stable as earlier occurrences get fixed.
		$occurrence_by_index = array();
		$seen_href           = array();
		for ( $i = 0; $i < $links->length; $i++ ) {
			$href = $links->item( $i )->getAttribute( 'href' );
			if ( '' === $href ) {
				$occurrence_by_index[ $i ] = 0;
				continue;
			}
			$seen_href[ $href ] = isset( $seen_href[ $href ] ) ? $seen_href[ $href ] + 1 : 1;
			$occurrence_by_index[ $i ] = $seen_href[ $href ];
		}

		$count = 0;
		$index = 0;

		foreach ( $links as $link ) {
			$occurrence = isset( $occurrence_by_index[ $index ] ) ? $occurrence_by_index[ $index ] : 1;
			$index++;
			$href = $link->getAttribute( 'href' );
			if ( '' === $href || '#' === $href[0] ) {
				continue;
			}
			$text = trim( preg_replace( '/\s+/', ' ', $link->textContent ) );
			if ( ! self::link_text_is_poor( $text, $href ) ) {
				continue;
			}
			$count++;

			$proposed = self::suggest_link_text( $link, $href );
			SourceFix_Store::add_fix(
				$post_id,
				SourceFix_Store::TYPE_LINK,
				$href,
				$text,
				$proposed,
				'manual',
				$occurrence
			);
		}

		return $count;
	}

	/**
	 * Whether a link's text is poor (generic, or a bare URL).
	 *
	 * @param string $text Link text.
	 * @param string $href Link href.
	 * @return bool
	 */
	private static function link_text_is_poor( $text, $href ) {
		if ( '' === $text ) {
			return true;
		}
		if ( in_array( strtolower( $text ), self::$generic_link_text, true ) ) {
			return true;
		}
		// Bare URL as the link text.
		if ( filter_var( $text, FILTER_VALIDATE_URL ) && $text === $href ) {
			return true;
		}
		return false;
	}

	/**
	 * Suggest better link text. Prefers the link's title attribute, then
	 * the title of the internal post it points to, then a domain-based
	 * label. The admin can edit the suggestion in the queue.
	 *
	 * @param DOMElement $link Link element.
	 * @param string     $href Link href.
	 * @return string
	 */
	private static function suggest_link_text( $link, $href ) {
		$title = trim( $link->getAttribute( 'title' ) );
		if ( '' !== $title ) {
			return $title;
		}
		// Internal link: use the target post's title.
		$home = home_url();
		if ( 0 === strpos( $href, $home ) ) {
			$target_id = url_to_postid( $href );
			if ( $target_id ) {
				$target_title = get_the_title( $target_id );
				if ( '' !== $target_title ) {
					return $target_title;
				}
			}
		}
		$host = wp_parse_url( $href, PHP_URL_HOST );
		if ( $host ) {
			return sprintf(
				/* translators: %s: domain name. */
				__( 'Visit %s', 'sourcefix' ),
				$host
			);
		}
		return '';
	}

	/**
	 * Scan heading structure. If there is a problem (no H1, multiple H1s,
	 * or a skipped level), ask the backend to fix the structure and queue
	 * the corrected structure for approval. Heading changes are never
	 * auto-applied: they change the page's structure.
	 *
	 * @param int         $post_id Post ID.
	 * @param WP_Post     $post    Post object.
	 * @param DOMDocument $doc     Parsed content.
	 * @return int 1 if a heading issue was found, else 0.
	 */
	private static function scan_headings( $post_id, $post, $doc ) {
		$headings = array();
		$xpath    = new DOMXPath( $doc );
		$nodes    = $xpath->query( '//h1|//h2|//h3|//h4|//h5|//h6' );
		foreach ( $nodes as $node ) {
			$text = trim( preg_replace( '/\s+/', ' ', $node->textContent ) );
			if ( '' === $text ) {
				continue;
			}
			$headings[] = array(
				'level' => (int) substr( strtolower( $node->tagName ), 1 ),
				'text'  => $text,
			);
		}

		if ( empty( $headings ) ) {
			return 0;
		}

		$issues = self::heading_issues( $headings );
		if ( empty( $issues ) ) {
			return 0;
		}

		$input = '';
		foreach ( $headings as $h ) {
			$input .= 'H' . $h['level'] . ': ' . $h['text'] . "\n";
		}

		$fixed = null;
		// Audit H-8: when this post already has a pending heading fix
		// with a real proposal (e.g. this is the re-scan after an
		// apply, or a re-publish), reuse it instead of spending
		// another AI call on the same fix.
		$existing_heading_fix = method_exists( 'SourceFix_Store', 'find_pending_fix' )
			? SourceFix_Store::find_pending_fix( $post_id, SourceFix_Store::TYPE_HEADING, 'headings:' . $post_id, 1 )
			: null;
		if ( $existing_heading_fix && '' !== $existing_heading_fix->proposed_text ) {
			$fixed = $existing_heading_fix->proposed_text;
		} elseif ( SourceFix_Licensing::allows_unlimited_fixes() || ! SourceFix_Store::monthly_cap_reached() ) {
			// Studio and above: the site's terminology applies to
			// headings as well as alt text, so the AI writes fixes in
			// the site's own words (audit S-M3).
			$terminology = '';
			if ( SourceFix_Licensing::allows_terminology() ) {
				$terminology = SourceFix_Store::terminology_context();
			}
			$fixed = SourceFix_API::fix_headings( $input, $terminology );
			if ( null !== $fixed ) {
				SourceFix_Store::increment_monthly_fix_count();
			}
		}

		SourceFix_Store::add_fix(
			$post_id,
			SourceFix_Store::TYPE_HEADING,
			'headings:' . $post_id,
			trim( $input ),
			null === $fixed ? '' : $fixed,
			null === $fixed ? 'manual' : 'ai'
		);

		return 1;
	}

	/**
	 * Find heading structure problems.
	 *
	 * @param array $headings List of array(level, text).
	 * @return array List of issue descriptions (empty when the structure is fine).
	 */
	private static function heading_issues( $headings ) {
		$issues = array();
		$h1     = 0;
		$prev   = 0;
		foreach ( $headings as $h ) {
			if ( 1 === $h['level'] ) {
				$h1++;
			}
			if ( $prev > 0 && $h['level'] > $prev + 1 ) {
				$issues[] = sprintf(
					/* translators: %1$d: heading level jumped from, %2$d: jumped to. */
					__( 'Skipped heading level from H%1$d to H%2$d.', 'sourcefix' ),
					$prev,
					$h['level']
				);
			}
			$prev = $h['level'];
		}
		if ( 0 === $h1 ) {
			$issues[] = __( 'No H1 heading found.', 'sourcefix' );
		}
		if ( $h1 > 1 ) {
			$issues[] = sprintf(
				/* translators: %d: number of H1 headings. */
				__( 'Multiple H1 headings found (%d).', 'sourcefix' ),
				$h1
			);
		}
		return $issues;
	}
}
