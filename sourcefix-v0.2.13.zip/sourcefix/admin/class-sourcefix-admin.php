<?php
/**
 * Admin screens: the fix approval queue, the audit log, and settings.
 *
 * The queue is where the site owner reviews proposed fixes. Each row shows
 * the post, the type, the original text, and the proposed fix, which can be
 * edited before approving. Approve applies the fix to the post; reject
 * keeps it in the history as rejected. Auto-applied fixes never appear
 * here as pending — they are already applied and listed in the audit log.
 *
 * @package SourceFix
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SourceFix_Admin {

	/**
	 * Menu slugs.
	 */
	const MENU_QUEUE   = 'sourcefix';
	const MENU_AUDIT   = 'sourcefix-audit';
	const MENU_SETTINGS = 'sourcefix-settings';
	const MENU_AGENCY  = 'sourcefix-agency';

	/**
	 * Register menus, actions, and settings.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menus' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_post_sourcefix_queue_action', array( __CLASS__, 'handle_queue_action' ) );
		add_action( 'admin_post_sourcefix_agency_report', array( __CLASS__, 'handle_agency_report' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_notices', array( __CLASS__, 'monthly_cap_notice' ) );
		add_action( 'admin_notices', array( __CLASS__, 'grace_period_notice' ) );
		add_action( 'admin_notices', array( __CLASS__, 'statement_draft_notice' ) );
	}

	/**
	 * Enqueue the admin stylesheet on SourceFix screens.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public static function enqueue_assets( $hook ) {
		if ( false === strpos( $hook, 'sourcefix' ) ) {
			return;
		}
		wp_enqueue_style(
			'sourcefix-admin',
			SOURCEFIX_PLUGIN_URL . 'assets/admin.css',
			array(),
			SOURCEFIX_VERSION
		);
	}

	/**
	 * Register the admin menu.
	 */
	public static function register_menus() {
		add_menu_page(
			__( 'SourceFix', 'sourcefix' ),
			__( 'SourceFix', 'sourcefix' ),
			'manage_options',
			self::MENU_QUEUE,
			array( __CLASS__, 'render_queue_page' ),
			'dashicons-universal-access',
			80
		);
		add_submenu_page(
			self::MENU_QUEUE,
			__( 'Fix Queue', 'sourcefix' ),
			__( 'Fix Queue', 'sourcefix' ),
			'manage_options',
			self::MENU_QUEUE,
			array( __CLASS__, 'render_queue_page' )
		);
		add_submenu_page(
			self::MENU_QUEUE,
			__( 'Audit Log', 'sourcefix' ),
			__( 'Audit Log', 'sourcefix' ),
			'manage_options',
			self::MENU_AUDIT,
			array( __CLASS__, 'render_audit_page' )
		);
		add_submenu_page(
			self::MENU_QUEUE,
			__( 'Settings', 'sourcefix' ),
			__( 'Settings', 'sourcefix' ),
			'manage_options',
			self::MENU_SETTINGS,
			array( __CLASS__, 'render_settings_page' )
		);
		// Agency dashboard: Agency plan only.
		if ( SourceFix_Licensing::allows_agency_dashboard() ) {
			add_submenu_page(
				self::MENU_QUEUE,
				__( 'Agency', 'sourcefix' ),
				__( 'Agency', 'sourcefix' ),
				'manage_options',
				self::MENU_AGENCY,
				array( __CLASS__, 'render_agency_page' )
			);
		}
	}

	/**
	 * Register the settings.
	 */
	public static function register_settings() {
		register_setting(
			'sourcefix_settings',
			'sourcefix_api_url',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'esc_url_raw',
				'default'           => SOURCEFIX_API_URL,
			)
		);
		register_setting(
			'sourcefix_settings',
			'sourcefix_auto_apply',
			array(
				'type'              => 'string',
				'sanitize_callback' => array( __CLASS__, 'sanitize_checkbox' ),
				'default'           => '0',
			)
		);
		// Per-site terminology memory (Studio and above). Stored as lines
		// of "term: preferred text".
		register_setting(
			'sourcefix_settings',
			'sourcefix_terminology',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_textarea_field',
				'default'           => '',
			)
		);
	}

	/**
	 * Sanitize a checkbox value to '1' or '0'.
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public static function sanitize_checkbox( $value ) {
		return $value ? '1' : '0';
	}

	/**
	 * Show a notice when the free monthly AI-fix allowance is used up.
	 * Paid plans have unlimited AI fixes, so the notice never shows there.
	 */
	public static function monthly_cap_notice() {
		$screen = get_current_screen();
		if ( ! $screen || false === strpos( $screen->id, 'sourcefix' ) ) {
			return;
		}
		if ( SourceFix_Licensing::allows_unlimited_fixes() ) {
			return;
		}
		if ( ! SourceFix_Store::monthly_cap_reached() ) {
			return;
		}
		printf(
			'<div class="notice notice-warning"><p>%s</p></div>',
			esc_html(
				sprintf(
					/* translators: %d: monthly fix allowance. */
					__( 'SourceFix has used its %d AI-authored fixes for this month. New issues are still detected and queued, but alt text and heading fixes will need to be written by hand until next month.', 'sourcefix' ),
					SOURCEFIX_FREE_MONTHLY_FIXES
				)
			)
		);
	}

	/**
	 * Show a notice while the site runs on its cached paid plan because
	 * Freemius could not confirm the licence (audit H-6). Shown on
	 * every admin screen — a licence problem deserves to be seen, not
	 * buried on the plugin's own pages. Never shows on a genuinely
	 * Free site or when Freemius confirms the plan live.
	 */
	public static function grace_period_notice() {
		$info = SourceFix_Licensing::cached_plan_info();
		if ( false === $info ) {
			return;
		}
		printf(
			'<div class="notice notice-warning is-dismissible"><p>%s</p></div>',
			esc_html(
				sprintf(
					/* translators: 1: plan name, 2: date the plan was last confirmed, 3: date the grace period ends. */
					__( 'SourceFix: your %1$s plan could not be confirmed with Freemius, so your paid features stay active for now. The plan was last confirmed on %2$s; if Freemius still cannot confirm it by %3$s, the site switches to the Free plan and the audit log is kept for 30 days instead of 12 months. Check the licence on the SourceFix account page, or contact support if the licence is active.', 'sourcefix' ),
					$info['label'],
					$info['last_seen'],
					$info['grace_ends']
				)
			)
		);
	}

	/**
	 * Tell the admin the statement page is waiting as a draft.
	 * Activation creates the page as a draft (audit M-5) and never
	 * publishes it, so the admin has to know it is there. Shown on
	 * SourceFix screens only, and only while the page is still a draft:
	 * once the admin publishes it, there is nothing to say.
	 */
	public static function statement_draft_notice() {
		$screen = get_current_screen();
		if ( ! $screen || false === strpos( $screen->id, 'sourcefix' ) ) {
			return;
		}
		$page_id = (int) get_option( 'sourcefix_statement_page_id', 0 );
		if ( ! $page_id ) {
			return;
		}
		$page = get_post( $page_id );
		if ( ! $page || 'draft' !== $page->post_status ) {
			return;
		}
		$edit_link = get_edit_post_link( $page_id );
		printf(
			'<div class="notice notice-info"><p>%s %s</p></div>',
			esc_html__( 'SourceFix created a draft Accessibility Statement page. Review it and publish it when you are ready:', 'sourcefix' ),
			$edit_link
				? sprintf(
					'<a href="%s">%s</a>',
					esc_url( $edit_link ),
					esc_html__( 'Edit the statement page', 'sourcefix' )
				)
				: esc_html__( 'the statement page in Pages.', 'sourcefix' )
		);
	}

	/**
	 * Handle an approve / reject action from the queue.
	 * The admin may also edit the proposed text before approving.
	 */
	public static function handle_queue_action() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'sourcefix' ) );
		}
		check_admin_referer( 'sourcefix_queue_action' );

		$fix_id = isset( $_POST['fix_id'] ) ? absint( $_POST['fix_id'] ) : 0;
		$action = isset( $_POST['queue_action'] ) ? sanitize_key( $_POST['queue_action'] ) : '';
		$fix    = $fix_id ? SourceFix_Store::get_fix( $fix_id ) : null;

		if ( ! $fix || SourceFix_Store::STATUS_PENDING !== $fix->status ) {
			wp_safe_redirect( add_query_arg( 'sourcefix_notice', 'not_found', admin_url( 'admin.php?page=' . self::MENU_QUEUE ) ) );
			exit;
		}

		if ( 'approve' === $action ) {
			$proposed = isset( $_POST['proposed_text'] ) ? sanitize_textarea_field( wp_unslash( $_POST['proposed_text'] ) ) : $fix->proposed_text;
			if ( '' === $proposed && SourceFix_Store::TYPE_ALT !== $fix->field_type ) {
				wp_safe_redirect( add_query_arg( 'sourcefix_notice', 'empty_text', admin_url( 'admin.php?page=' . self::MENU_QUEUE ) ) );
				exit;
			}
			if ( $proposed !== $fix->proposed_text ) {
				SourceFix_Store::set_fix_proposed_text( $fix_id, $proposed );
			}
			$ok = SourceFix_Applier::apply_fix( $fix_id );
			$notice = $ok ? 'applied' : 'apply_failed';
		} elseif ( 'reject' === $action ) {
			SourceFix_Store::set_fix_status( $fix_id, SourceFix_Store::STATUS_REJECTED );
			SourceFix_Store::audit_log(
				(int) $fix->post_id,
				'fix_rejected',
				sprintf(
					/* translators: %s: fix type. */
					__( 'Rejected a proposed %s fix.', 'sourcefix' ),
					$fix->field_type
				)
			);
			$notice = 'rejected';
		} else {
			$notice = 'not_found';
		}

		wp_safe_redirect( add_query_arg( 'sourcefix_notice', $notice, admin_url( 'admin.php?page=' . self::MENU_QUEUE ) ) );
		exit;
	}

	/**
	 * Render the fix queue page.
	 */
	public static function render_queue_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'sourcefix' ) );
		}

		$notice = isset( $_GET['sourcefix_notice'] ) ? sanitize_key( $_GET['sourcefix_notice'] ) : '';
		$pending_count  = SourceFix_Store::count_fixes( SourceFix_Store::STATUS_PENDING );
		$applied_count  = SourceFix_Store::count_fixes( SourceFix_Store::STATUS_APPLIED );
		$rejected_count = SourceFix_Store::count_fixes( SourceFix_Store::STATUS_REJECTED );
		$fixes = SourceFix_Store::get_fixes( SourceFix_Store::STATUS_PENDING, 100, 0 );

		echo '<div class="wrap sourcefix-wrap">';
		echo '<h1>' . esc_html__( 'SourceFix — Fix Queue', 'sourcefix' ) . '</h1>';
		echo '<p>' . esc_html__( 'Proposed fixes from the last publish-time scans. Approve a fix to apply it to the post, or reject it to keep it in the history as rejected. You can edit the proposed text before approving.', 'sourcefix' ) . '</p>';

		if ( 'applied' === $notice ) {
			echo '<div class="notice notice-success"><p>' . esc_html__( 'Fix applied.', 'sourcefix' ) . '</p></div>';
		} elseif ( 'rejected' === $notice ) {
			echo '<div class="notice notice-success"><p>' . esc_html__( 'Fix rejected.', 'sourcefix' ) . '</p></div>';
		} elseif ( 'apply_failed' === $notice ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'The fix could not be applied. The content may have changed since the fix was proposed.', 'sourcefix' ) . '</p></div>';
		} elseif ( 'empty_text' === $notice ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'The proposed text is empty. Enter a fix before approving.', 'sourcefix' ) . '</p></div>';
		}

		printf(
			'<p><strong>%s</strong> %s &middot; %s &middot; %s</p>',
			esc_html__( 'Queue:', 'sourcefix' ),
			esc_html( sprintf( __( '%d pending', 'sourcefix' ), $pending_count ) ),
			esc_html( sprintf( __( '%d applied', 'sourcefix' ), $applied_count ) ),
			esc_html( sprintf( __( '%d rejected', 'sourcefix' ), $rejected_count ) )
		);

		if ( empty( $fixes ) ) {
			echo '<p>' . esc_html__( 'The queue is empty. Publish or update a post and SourceFix will scan it for issues.', 'sourcefix' ) . '</p>';
			echo '</div>';
			return;
		}

		echo '<table class="widefat fixed striped sourcefix-queue">';
		echo '<thead><tr>';
		echo '<th>' . esc_html__( 'Post', 'sourcefix' ) . '</th>';
		echo '<th>' . esc_html__( 'Type', 'sourcefix' ) . '</th>';
		echo '<th>' . esc_html__( 'Found', 'sourcefix' ) . '</th>';
		echo '<th>' . esc_html__( 'Proposed fix', 'sourcefix' ) . '</th>';
		echo '<th>' . esc_html__( 'Actions', 'sourcefix' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $fixes as $fix ) {
			$post_title = get_the_title( (int) $fix->post_id );
			$post_title = '' !== $post_title ? $post_title : sprintf(
				/* translators: %d: post ID. */
				__( 'Post #%d', 'sourcefix' ),
				$fix->post_id
			);
			$edit_link = get_edit_post_link( (int) $fix->post_id );

			echo '<tr>';
			echo '<td>';
			if ( $edit_link ) {
				echo '<a href="' . esc_url( $edit_link ) . '">' . esc_html( $post_title ) . '</a>';
			} else {
				echo esc_html( $post_title );
			}
			echo '</td>';
			echo '<td>' . esc_html( self::type_label( $fix->field_type ) ) . '</td>';
			echo '<td>' . esc_html( self::found_label( $fix ) ) . '</td>';
			echo '<td>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'sourcefix_queue_action' );
			echo '<input type="hidden" name="action" value="sourcefix_queue_action" />';
			echo '<input type="hidden" name="fix_id" value="' . esc_attr( $fix->id ) . '" />';
			if ( SourceFix_Store::TYPE_HEADING === $fix->field_type ) {
				echo '<textarea name="proposed_text" rows="4" class="large-text code">' . esc_textarea( $fix->proposed_text ) . '</textarea>';
				if ( '' === $fix->proposed_text ) {
					echo '<p class="description">' . esc_html__( 'No AI fix was produced. Paste the corrected heading structure here (one per line, "H1: ...").', 'sourcefix' ) . '</p>';
				}
			} else {
				echo '<input type="text" name="proposed_text" value="' . esc_attr( $fix->proposed_text ) . '" class="large-text" />';
				if ( '' === $fix->proposed_text ) {
					echo '<p class="description">' . esc_html__( 'No AI fix was produced. Enter the fix here.', 'sourcefix' ) . '</p>';
				}
			}
			echo '</td><td>';
			echo '<button type="submit" name="queue_action" value="approve" class="button button-primary">' . esc_html__( 'Approve', 'sourcefix' ) . '</button> ';
			echo '<button type="submit" name="queue_action" value="reject" class="button">' . esc_html__( 'Reject', 'sourcefix' ) . '</button>';
			echo '</form>';
			echo '</td></tr>';
		}

		echo '</tbody></table>';
		echo '</div>';
	}

	/**
	 * Human-readable type label.
	 *
	 * @param string $type Fix type.
	 * @return string
	 */
	private static function type_label( $type ) {
		switch ( $type ) {
			case SourceFix_Store::TYPE_ALT:
				return __( 'Alt text', 'sourcefix' );
			case SourceFix_Store::TYPE_LINK:
				return __( 'Link text', 'sourcefix' );
			case SourceFix_Store::TYPE_HEADING:
				return __( 'Headings', 'sourcefix' );
			default:
				return $type;
		}
	}

	/**
	 * What was found, for the queue table.
	 *
	 * @param object $fix Fix row.
	 * @return string
	 */
	private static function found_label( $fix ) {
		$occurrence = isset( $fix->occurrence ) ? (int) $fix->occurrence : 1;
		$suffix     = $occurrence > 1
			? ' ' . sprintf(
				/* translators: %d: occurrence number among identical elements. */
				__( '(occurrence %d of the identical elements)', 'sourcefix' ),
				$occurrence
			)
			: '';
		switch ( $fix->field_type ) {
			case SourceFix_Store::TYPE_ALT:
				return sprintf(
					/* translators: %s: image URL. */
					__( 'Image without alt text: %s', 'sourcefix' ),
					$fix->target
				) . $suffix;
			case SourceFix_Store::TYPE_LINK:
				return sprintf(
					/* translators: %1$s: link text found, %2$s: link URL. */
					__( 'Poor link text "%1$s" for %2$s', 'sourcefix' ),
					$fix->original_text,
					$fix->target
				) . $suffix;
			case SourceFix_Store::TYPE_HEADING:
				return __( 'Heading structure issue (see proposed structure).', 'sourcefix' );
			default:
				return $fix->original_text;
		}
	}

	/**
	 * Render the audit log page.
	 */
	public static function render_audit_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'sourcefix' ) );
		}

		$entries = SourceFix_Store::get_audit_log( 100, 0 );

		echo '<div class="wrap sourcefix-wrap">';
		echo '<h1>' . esc_html__( 'SourceFix — Audit Log', 'sourcefix' ) . '</h1>';
		echo '<p>' . esc_html__( 'Every fix applied, every scan, and every statement update. This is the same record the public statement is built from.', 'sourcefix' ) . '</p>';

		if ( empty( $entries ) ) {
			echo '<p>' . esc_html__( 'Nothing logged yet.', 'sourcefix' ) . '</p>';
			echo '</div>';
			return;
		}

		echo '<table class="widefat fixed striped">';
		echo '<thead><tr>';
		echo '<th>' . esc_html__( 'When', 'sourcefix' ) . '</th>';
		echo '<th>' . esc_html__( 'Post', 'sourcefix' ) . '</th>';
		echo '<th>' . esc_html__( 'Action', 'sourcefix' ) . '</th>';
		echo '<th>' . esc_html__( 'Detail', 'sourcefix' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $entries as $entry ) {
			$post_title = $entry->post_id ? get_the_title( (int) $entry->post_id ) : __( 'Site', 'sourcefix' );
			echo '<tr>';
			echo '<td>' . esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $entry->created_at ) ) ) . '</td>';
			echo '<td>' . esc_html( $post_title ) . '</td>';
			echo '<td>' . esc_html( $entry->action ) . '</td>';
			echo '<td>' . esc_html( $entry->detail ) . '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
		echo '</div>';
	}

	/**
	 * Render the settings page.
	 */
	public static function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'sourcefix' ) );
		}

		$api_url       = SourceFix_API::base_url();
		$auto_apply    = '1' === get_option( 'sourcefix_auto_apply', '0' );
		$used          = SourceFix_Store::monthly_fix_count();
		$statement_id  = (int) get_option( 'sourcefix_statement_page_id', 0 );
		$statement_url = $statement_id ? get_permalink( $statement_id ) : '';
		$statement_page = $statement_id ? get_post( $statement_id ) : null;
		$plan          = SourceFix_Licensing::current_plan();
		$plan_label    = SourceFix_Licensing::plan_label();
		$unlimited     = SourceFix_Licensing::allows_unlimited_fixes();
		$terminology   = get_option( 'sourcefix_terminology', '' );

		echo '<div class="wrap sourcefix-wrap">';
		echo '<h1>' . esc_html__( 'SourceFix — Settings', 'sourcefix' ) . '</h1>';

		echo '<h2>' . esc_html__( 'Plan', 'sourcefix' ) . '</h2>';
		printf(
			'<p>%s</p>',
			esc_html(
				sprintf(
					/* translators: %s: plan name. */
					__( 'Current plan: %s.', 'sourcefix' ),
					$plan_label
				)
			)
		);
		if ( SourceFix_Licensing::PLAN_FREE === $plan ) {
			printf(
				'<p><a class="button button-primary" href="%s">%s</a></p>',
				esc_url( SourceFix_Licensing::upgrade_url() ),
				esc_html__( 'Upgrade for unlimited AI fixes, auto-apply, and more', 'sourcefix' )
			);
			echo '<p>' . esc_html__( 'Free includes up to 50 AI-authored fixes per month, the approval queue, and a dated statement listing applied fixes from the last 30 days. Solo ($79/year) adds unlimited authoring, auto-apply for low-risk fixes, and a 12-month audit log. Studio ($149/year) adds per-site terminology memory. Agency ($299/year) adds the agency dashboard and client reporting.', 'sourcefix' ) . '</p>';
		}

		echo '<form method="post" action="options.php">';
		settings_fields( 'sourcefix_settings' );
		echo '<table class="form-table"><tbody>';

		echo '<tr><th scope="row"><label for="sourcefix_api_url">' . esc_html__( 'Backend API URL', 'sourcefix' ) . '</label></th><td>';
		echo '<input type="url" id="sourcefix_api_url" name="sourcefix_api_url" value="' . esc_attr( $api_url ) . '" class="regular-text" />';
		echo '<p class="description">' . esc_html__( 'The SourceFix AI authoring service. Only change this if you run your own backend.', 'sourcefix' ) . '</p>';
		echo '</td></tr>';

		echo '<tr><th scope="row">' . esc_html__( 'Auto-apply low-risk fixes', 'sourcefix' ) . '</th><td>';
		if ( SourceFix_Licensing::allows_auto_apply() ) {
			echo '<label><input type="hidden" name="sourcefix_auto_apply" value="0" /><input type="checkbox" name="sourcefix_auto_apply" value="1"' . checked( $auto_apply, true, false ) . ' /> ' . esc_html__( 'Automatically apply low-risk alt text fixes (clear context, confident AI result). Everything else always goes to the approval queue.', 'sourcefix' ) . '</label>';
		} else {
			echo '<p class="description">' . esc_html__( 'Auto-apply is included in the Solo plan and above. On the Free plan every fix waits in the approval queue.', 'sourcefix' ) . '</p>';
		}
		echo '</td></tr>';

		echo '<tr><th scope="row"><label for="sourcefix_terminology">' . esc_html__( 'Terminology memory', 'sourcefix' ) . '</label></th><td>';
		if ( SourceFix_Licensing::allows_terminology() ) {
			echo '<textarea id="sourcefix_terminology" name="sourcefix_terminology" rows="5" class="large-text code">' . esc_textarea( $terminology ) . '</textarea>';
			echo '<p class="description">' . esc_html__( 'One term per line, as "term: preferred text". The AI uses these words when it writes alt text and headings for this site.', 'sourcefix' ) . '</p>';
		} else {
			echo '<p class="description">' . esc_html__( 'Terminology memory is included in the Studio plan and above. It teaches the AI this site\u2019s preferred wording.', 'sourcefix' ) . '</p>';
		}
		echo '</td></tr>';

		echo '</tbody></table>';
		submit_button();
		echo '</form>';

		echo '<h2>' . esc_html__( 'Usage this month', 'sourcefix' ) . '</h2>';
		if ( $unlimited ) {
			printf(
				'<p>%s</p>',
				esc_html(
					sprintf(
						/* translators: %d: fixes used. */
						__( 'AI-authored fixes used: %d (unlimited on your plan).', 'sourcefix' ),
						$used
					)
				)
			);
		} else {
			printf(
				'<p>%s</p>',
				esc_html(
					sprintf(
						/* translators: %1$d: fixes used, %2$d: monthly allowance. */
						__( 'AI-authored fixes used: %1$d of %2$d.', 'sourcefix' ),
						$used,
						SOURCEFIX_FREE_MONTHLY_FIXES
					)
				)
			);
		}

		echo '<h2>' . esc_html__( 'Public statement', 'sourcefix' ) . '</h2>';
		if ( $statement_page && 'draft' === $statement_page->post_status ) {
			// The statement page is a draft (audit M-5): it is not
			// public until the admin publishes it. Point at the
			// editor, not the public URL, which visitors cannot see yet.
			$edit_link = get_edit_post_link( $statement_id );
			if ( $edit_link ) {
				printf(
					'<p><a href="%s">%s</a></p>',
					esc_url( $edit_link ),
					esc_html__( 'Review the draft accessibility statement', 'sourcefix' )
				);
			}
			echo '<p>' . esc_html__( 'The statement page is still a draft. It is not public until you publish it.', 'sourcefix' ) . '</p>';
		} elseif ( $statement_url ) {
			printf(
				'<p><a href="%s" target="_blank" rel="noopener">%s</a></p>',
				esc_url( $statement_url ),
				esc_html__( 'View the public accessibility statement', 'sourcefix' )
			);
		} else {
			echo '<p>' . esc_html__( 'No statement page exists yet. It is created automatically when the plugin is activated.', 'sourcefix' ) . '</p>';
		}
		echo '<p>' . esc_html__( 'The statement lists what SourceFix has fixed on this site and when. It describes the work done; it does not claim the site complies with any accessibility standard.', 'sourcefix' ) . '</p>';

		echo '</div>';
	}

	/**
	 * Render the agency dashboard (Agency plan only).
	 *
	 * A summary of this site's SourceFix activity plus a client report
	 * generator: pick a date range and download a dated CSV of the fixes
	 * applied in that period, ready to send to a client.
	 */
	public static function render_agency_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'sourcefix' ) );
		}
		if ( ! SourceFix_Licensing::allows_agency_dashboard() ) {
			wp_die( esc_html__( 'The agency dashboard is included in the Agency plan.', 'sourcefix' ) );
		}

		$pending   = SourceFix_Store::count_fixes( SourceFix_Store::STATUS_PENDING );
		$applied   = SourceFix_Store::count_fixes( SourceFix_Store::STATUS_APPLIED );
		$rejected  = SourceFix_Store::count_fixes( SourceFix_Store::STATUS_REJECTED );
		$used      = SourceFix_Store::monthly_fix_count();
		$statement = get_option( 'sourcefix_statement_updated', '' );

		echo '<div class="wrap sourcefix-wrap">';
		echo '<h1>' . esc_html__( 'SourceFix — Agency', 'sourcefix' ) . '</h1>';
		echo '<p>' . esc_html__( 'Activity for this site, and a client report you can send to the site owner.', 'sourcefix' ) . '</p>';

		echo '<h2>' . esc_html__( 'This site', 'sourcefix' ) . '</h2>';
		printf(
			'<p>%s</p>',
			esc_html(
				sprintf(
					/* translators: %1$d: applied, %2$d: pending, %3$d: rejected. */
					__( '%1$d fixes applied, %2$d pending review, %3$d rejected.', 'sourcefix' ),
					$applied,
					$pending,
					$rejected
				)
			)
		);
		printf(
			'<p>%s</p>',
			esc_html(
				sprintf(
					/* translators: %d: AI fixes used this month. */
					__( 'AI-authored fixes this month: %d (unlimited on the Agency plan).', 'sourcefix' ),
					$used
				)
			)
		);
		if ( $statement ) {
			printf(
				'<p>%s</p>',
				esc_html(
					sprintf(
						/* translators: %s: date. */
						__( 'Public statement last updated: %s.', 'sourcefix' ),
						date_i18n( get_option( 'date_format' ), strtotime( $statement ) )
					)
				)
			);
		}

		echo '<h2>' . esc_html__( 'Client report', 'sourcefix' ) . '</h2>';
		echo '<p>' . esc_html__( 'Download a dated list of the fixes applied in a period, as a CSV file.', 'sourcefix' ) . '</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'sourcefix_agency_report' );
		echo '<input type="hidden" name="action" value="sourcefix_agency_report" />';
		$month_ago = gmdate( 'Y-m-d', time() - 30 * DAY_IN_SECONDS );
		$today     = gmdate( 'Y-m-d' );
		echo '<label>' . esc_html__( 'From', 'sourcefix' ) . ' <input type="date" name="report_from" value="' . esc_attr( $month_ago ) . '" required /></label> ';
		echo '<label>' . esc_html__( 'To', 'sourcefix' ) . ' <input type="date" name="report_to" value="' . esc_attr( $today ) . '" required /></label> ';
		submit_button( __( 'Download report (CSV)', 'sourcefix' ), 'secondary', 'submit', false );
		echo '</form>';

		echo '</div>';
	}

	/**
	 * CSV-injection guard for one cell of the Agency client report
	 * (audit M-7, OWASP CSV Injection cheat sheet).
	 *
	 * Rule: if the first significant character of the value is one
	 * of `=`, `+`, `-`, `@`, tab, or carriage return, prefix the
	 * whole value with a single quote `'`, which forces spreadsheet
	 * apps to treat the cell as text instead of a formula. Leading
	 * spaces and tabs are ignored when looking for the trigger,
	 * because spreadsheet apps ignore them too ("  =cmd" still runs
	 * as a formula), but the prefix goes at the very start so the
	 * original value is preserved. Anything else — including a
	 * trigger character in the middle of a value ("2+2=4",
	 * "mail@example.com") — is returned unchanged. A value that
	 * already starts with a single quote is already text and is
	 * left alone.
	 *
	 * @param mixed $value Cell value.
	 * @return string Guarded cell value.
	 */
	public static function csv_cell( $value ) {
		$value = (string) $value;
		if ( '' === $value ) {
			return $value;
		}
		$first = ltrim( $value, " \t" );
		if ( '' === $first ) {
			return $value;
		}
		if ( in_array( $first[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ) {
			return "'" . $value;
		}
		return $value;
	}

	/**
	 * Build one guarded row of the Agency client report.
	 *
	 * Every column goes through csv_cell(): the date is
	 * machine-shaped, but the post title is admin-written, the field
	 * type comes from the scan, and the fix text is AI output or
	 * admin-edited — all four can start with a formula character.
	 * The header row ('date', 'post', 'type', 'fix') is a static
	 * literal and contains no trigger character; if it ever becomes
	 * dynamic it must go through csv_cell() too.
	 *
	 * @param object $row Fix row from SourceFix_Store::fixes_table().
	 * @return array Four guarded CSV cells.
	 */
	public static function agency_report_row( $row ) {
		return array(
			self::csv_cell( $row->decided_at ? substr( $row->decided_at, 0, 10 ) : substr( $row->created_at, 0, 10 ) ),
			self::csv_cell( get_the_title( (int) $row->post_id ) ),
			self::csv_cell( $row->field_type ),
			self::csv_cell( $row->proposed_text ),
		);
	}

	/**
	 * Handle a client report download (Agency plan only).
	 * Streams a CSV of applied fixes in the requested date range.
	 */
	public static function handle_agency_report() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'sourcefix' ) );
		}
		check_admin_referer( 'sourcefix_agency_report' );
		if ( ! SourceFix_Licensing::allows_agency_dashboard() ) {
			wp_die( esc_html__( 'The agency dashboard is included in the Agency plan.', 'sourcefix' ) );
		}

		$from = isset( $_POST['report_from'] ) ? sanitize_text_field( wp_unslash( $_POST['report_from'] ) ) : '';
		$to   = isset( $_POST['report_to'] ) ? sanitize_text_field( wp_unslash( $_POST['report_to'] ) ) : '';
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to ) ) {
			wp_die( esc_html__( 'Invalid date range.', 'sourcefix' ) );
		}

		global $wpdb;
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . SourceFix_Store::fixes_table() . ' WHERE status = %s AND decided_at >= %s AND decided_at < DATE_ADD(%s, INTERVAL 1 DAY) ORDER BY decided_at ASC',
				SourceFix_Store::STATUS_APPLIED,
				$from,
				$to
			)
		);

		$filename = 'sourcefix-report-' . $from . '-to-' . $to . '.csv';
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		$out = fopen( 'php://output', 'w' );
		fputcsv( $out, array( 'date', 'post', 'type', 'fix' ) );
		foreach ( $rows as $row ) {
			fputcsv( $out, self::agency_report_row( $row ) );
		}
		fclose( $out );
		SourceFix_Store::audit_log( 0, 'agency_report', sprintf( __( 'Downloaded a client report for %s to %s (%d fixes).', 'sourcefix' ), $from, $to, count( $rows ) ) );
		exit;
	}
}
