<?php
/**
 * Plan and licensing logic for SourceFix.
 *
 * SourceFix is sold through Freemius. The plans (unique names) are:
 *  - free    — Free, $0: 1 site, up to 50 AI fixes/month, approval queue,
 *              statement published once.
 *  - solo    — Solo, $79/yr: 1 site, unlimited authoring, auto-apply
 *              low-risk fixes, statement re-published on every change,
 *              12-month audit log.
 *  - studio  — Studio, $149/yr: 5 sites, plus per-site terminology memory.
 *  - agency  — Agency, $299/yr: 25 sites, plus agency dashboard and
 *              client reporting.
 *
 * The plan names and prices are configured in the Freemius Developer
 * Dashboard (see plugin/freemius-config.md). The Freemius product must be
 * registered there before the SDK can report a real plan; until then the
 * plugin runs as the Free tier and every feature below degrades safely.
 *
 * For testing a paid plan without a real purchase, the plan can be
 * overridden — but ONLY when the test-only file
 * `includes/test-overrides.php` is present in the plugin directory. That
 * file defines the SOURCEFIX_TEST_OVERRIDES constant and is NEVER shipped
 * (it must be excluded from the release zip and from the WordPress.org
 * submission). Without that file, the constant and the `sourcefix_plan`
 * filter below are dead code: no code on the site, including a
 * code-snippets plugin, can unlock a paid plan. A plan override requires
 * file access by design.
 *
 * Fail-closed plan downgrade (audit H-6): a paying site must never
 * silently drop to Free because Freemius is temporarily unavailable
 * (SDK not loaded, licence sync hiccup, Freemius API down). The last
 * known paid plan is cached in `sourcefix_last_paid_plan` with a
 * timestamp. While the cache is inside its grace period the site keeps
 * the paid plan — and the paid 12-month audit retention. A downgrade
 * happens only when (a) the grace period has expired, or (b) Freemius
 * positively reports an expired or cancelled licence. The daily prune
 * never deletes below the cached paid retention. While the site runs on
 * the cached plan, an admin notice says so. No Freemius API token is
 * involved: every signal here comes from the SDK's local state.
 *
 * @package SourceFix
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SourceFix_Licensing {

	/**
	 * Plan slugs.
	 */
	const PLAN_FREE   = 'free';
	const PLAN_SOLO   = 'solo';
	const PLAN_STUDIO = 'studio';
	const PLAN_AGENCY = 'agency';

	/**
	 * All plan slugs, lowest to highest.
	 *
	 * @var array
	 */
	private static $plans = array(
		self::PLAN_FREE,
		self::PLAN_SOLO,
		self::PLAN_STUDIO,
		self::PLAN_AGENCY,
	);

	/**
	 * Monthly AI-fix allowance on the Free plan.
	 */
	const FREE_MONTHLY_FIXES = 50;

	/**
	 * Audit log retention in days, by plan.
	 */
	const FREE_AUDIT_RETENTION_DAYS = 30;
	const PAID_AUDIT_RETENTION_DAYS = 365;

	/**
	 * Grace period in days before a cached paid plan is dropped when
	 * Freemius cannot confirm the licence. 14 days covers an SDK sync
	 * outage, a deactivation/re-activation, and Freemius API downtime,
	 * while a genuinely lapsed annual licence still loses paid features
	 * within two weeks. A positively expired or cancelled licence (see
	 * licence_expired_or_cancelled()) downgrades immediately, with no
	 * grace period.
	 */
	const GRACE_PERIOD_DAYS = 14;

	/**
	 * wp_options key for the last known paid plan cache. Value:
	 * array( 'plan' => slug, 'at' => unix timestamp of last sighting ).
	 */
	const LAST_PAID_PLAN_OPTION = 'sourcefix_last_paid_plan';

	/**
	 * How often the cache timestamp is refreshed while the same paid
	 * plan keeps being observed. Avoids an option write on every admin
	 * page load; a one-day-old timestamp is fresh enough for a
	 * 14-day grace period.
	 */
	const CACHE_REFRESH_INTERVAL = DAY_IN_SECONDS;

	/**
	 * Whether the Freemius SDK is initialized with a real product.
	 *
	 * @return bool
	 */
	public static function is_freemius_active() {
		return function_exists( 'sourcefix_fs' ) && sourcefix_fs() instanceof Freemius;
	}

	/**
	 * The current plan for this site — fail closed (audit H-6).
	 *
	 * Test override (constant or filter) wins, then the live Freemius
	 * plan. When Freemius cannot confirm a paid plan, the last known
	 * paid plan is served from cache for the grace period instead of
	 * silently dropping to Free; only an explicit expired/cancelled
	 * licence, or an expired grace period, downgrades the site. A
	 * paying plan that is not one of the known slugs is treated as
	 * Solo, the lowest paid tier.
	 *
	 * @return string One of free, solo, studio, agency.
	 */
	public static function current_plan() {
		// Test override — active ONLY when the test-only file
		// includes/test-overrides.php is present (it defines
		// SOURCEFIX_TEST_OVERRIDES). The shipped plugin never defines
		// that constant, so this block is dead code in production: the
		// constant in wp-config.php or the filter alone cannot unlock a
		// paid plan.
		if ( defined( 'SOURCEFIX_TEST_OVERRIDES' ) && SOURCEFIX_TEST_OVERRIDES ) {
			if ( defined( 'SOURCEFIX_PLAN_OVERRIDE' ) && is_string( SOURCEFIX_PLAN_OVERRIDE ) ) {
				$override = strtolower( trim( SOURCEFIX_PLAN_OVERRIDE ) );
				if ( in_array( $override, self::$plans, true ) ) {
					return $override;
				}
			}
			$filtered = apply_filters( 'sourcefix_plan', '' );
			if ( is_string( $filtered ) && in_array( strtolower( trim( $filtered ) ), self::$plans, true ) ) {
				return strtolower( trim( $filtered ) );
			}
		}

		$live = self::live_plan();

		// Freemius positively reports a paid plan: serve it and
		// refresh the cache so a later outage has something to fall
		// back on.
		if ( is_string( $live ) && self::PLAN_FREE !== $live ) {
			self::remember_paid_plan( $live );
			return $live;
		}

		// Freemius positively reports Free AND the local licence is
		// expired or cancelled: the only fast downgrade path. No grace
		// period — the licence is genuinely over.
		if ( self::PLAN_FREE === $live && self::licence_expired_or_cancelled() ) {
			self::forget_paid_plan();
			return self::PLAN_FREE;
		}

		// Freemius inactive, or reporting Free with no expired/cancelled
		// signal (ambiguous SDK state): fail closed on the cached paid
		// plan while it is inside the grace period.
		$cached = self::cached_paid_plan();
		if ( false !== $cached ) {
			return $cached['plan'];
		}

		// No valid cache: genuinely Free (or the grace period expired).
		// Drop any stale cache row so a later re-activation starts clean.
		self::forget_paid_plan();
		return self::PLAN_FREE;
	}

	/**
	 * The plan Freemius reports right now, without any fail-closed
	 * fallback.
	 *
	 * @return string|null Paid plan slug, 'free' when Freemius is active
	 *                     and reports no paid plan, null when Freemius
	 *                     is inactive (SDK not loaded / not registered).
	 */
	private static function live_plan() {
		if ( ! self::is_freemius_active() ) {
			return null;
		}

		$fs = sourcefix_fs();
		if ( $fs->is_plan( self::PLAN_AGENCY, true ) ) {
			return self::PLAN_AGENCY;
		}
		if ( $fs->is_plan( self::PLAN_STUDIO, true ) ) {
			return self::PLAN_STUDIO;
		}
		if ( $fs->is_plan( self::PLAN_SOLO, true ) ) {
			return self::PLAN_SOLO;
		}
		// Paying (or trialling) but on an unknown plan: lowest paid tier.
		if ( $fs->is_paying_or_trial() ) {
			return self::PLAN_SOLO;
		}
		return self::PLAN_FREE;
	}

	/**
	 * Whether the Freemius SDK holds a licence that is positively
	 * expired or cancelled. This is the only signal that downgrades a
	 * site immediately, with no grace period. It reads the licence
	 * object the SDK keeps locally — no API token, no server call.
	 * A missing licence object is NOT a signal: a site that never had
	 * a licence, or whose licence state has not synced yet, must not
	 * be treated as expired.
	 *
	 * @return bool
	 */
	public static function licence_expired_or_cancelled() {
		if ( ! self::is_freemius_active() ) {
			return false;
		}
		$fs = sourcefix_fs();
		if ( ! method_exists( $fs, '_get_license' ) ) {
			return false;
		}
		$licence = $fs->_get_license();
		if ( ! is_object( $licence ) ) {
			return false;
		}
		if ( method_exists( $licence, 'is_expired' ) && $licence->is_expired() ) {
			return true;
		}
		// FS_Plugin_License::is_active() is false when cancelled.
		if ( method_exists( $licence, 'is_active' ) && ! $licence->is_active() ) {
			return true;
		}
		return false;
	}

	/**
	 * The cached last known paid plan, when it is still inside the
	 * grace period.
	 *
	 * @return array|false array( 'plan' => slug, 'at' => timestamp ),
	 *                     or false when there is no cache, the cache
	 *                     is malformed, or the grace period expired.
	 */
	public static function cached_paid_plan() {
		$cached = get_option( self::LAST_PAID_PLAN_OPTION, false );
		if ( ! is_array( $cached ) || empty( $cached['plan'] ) || empty( $cached['at'] ) ) {
			return false;
		}
		$plan = strtolower( trim( (string) $cached['plan'] ) );
		if ( ! in_array( $plan, self::$plans, true ) || self::PLAN_FREE === $plan ) {
			return false;
		}
		$at = (int) $cached['at'];
		if ( $at <= 0 || $at + self::GRACE_PERIOD_DAYS * DAY_IN_SECONDS < time() ) {
			return false;
		}
		return array(
			'plan' => $plan,
			'at'   => $at,
		);
	}

	/**
	 * Whether the site is currently running on the cached paid plan
	 * (Freemius could not confirm the licence, grace period active).
	 * Used by the admin notice. False when the live Freemius state
	 * reports the paid plan, when a test override is active, or when
	 * the site is genuinely Free.
	 *
	 * @return bool
	 */
	public static function is_on_cached_plan() {
		if ( defined( 'SOURCEFIX_TEST_OVERRIDES' ) && SOURCEFIX_TEST_OVERRIDES ) {
			return false;
		}
		$live = self::live_plan();
		if ( is_string( $live ) && self::PLAN_FREE !== $live ) {
			return false;
		}
		if ( self::PLAN_FREE === $live && self::licence_expired_or_cancelled() ) {
			return false;
		}
		return false !== self::cached_paid_plan();
	}

	/**
	 * Details for the cached-plan admin notice: plan label, the date
	 * the grace period ends, and the date the plan was last confirmed.
	 *
	 * @return array|false array( 'plan', 'label', 'last_seen', 'grace_ends' )
	 *                     (dates as 'Y-m-d'), or false when not on a
	 *                     cached plan.
	 */
	public static function cached_plan_info() {
		if ( ! self::is_on_cached_plan() ) {
			return false;
		}
		$cached = self::cached_paid_plan();
		return array(
			'plan'      => $cached['plan'],
			'label'     => self::plan_label_for( $cached['plan'] ),
			'last_seen' => gmdate( 'Y-m-d', $cached['at'] ),
			'grace_ends' => gmdate( 'Y-m-d', $cached['at'] + self::GRACE_PERIOD_DAYS * DAY_IN_SECONDS ),
		);
	}

	/**
	 * Record a paid plan sighting in the cache. Writes at most once a
	 * day for an unchanged plan, so normal admin traffic does not
	 * rewrite the option on every page load.
	 *
	 * @param string $plan Paid plan slug.
	 */
	private static function remember_paid_plan( $plan ) {
		$cached = get_option( self::LAST_PAID_PLAN_OPTION, false );
		if ( is_array( $cached )
			&& isset( $cached['plan'] ) && $cached['plan'] === $plan
			&& isset( $cached['at'] ) && (int) $cached['at'] > time() - self::CACHE_REFRESH_INTERVAL
		) {
			return;
		}
		update_option(
			self::LAST_PAID_PLAN_OPTION,
			array(
				'plan' => $plan,
				'at'   => time(),
			)
		);
	}

	/**
	 * Drop the cached paid plan, if one is stored.
	 */
	private static function forget_paid_plan() {
		if ( false !== get_option( self::LAST_PAID_PLAN_OPTION, false ) ) {
			delete_option( self::LAST_PAID_PLAN_OPTION );
		}
	}

	/**
	 * Whether the current plan is a paid plan.
	 *
	 * @return bool
	 */
	public static function is_paid() {
		return self::PLAN_FREE !== self::current_plan();
	}

	/**
	 * Whether the current plan is at least the given plan.
	 *
	 * @param string $plan Plan slug.
	 * @return bool
	 */
	public static function is_at_least( $plan ) {
		$current = array_search( self::current_plan(), self::$plans, true );
		$wanted  = array_search( $plan, self::$plans, true );
		return false !== $current && false !== $wanted && $current >= $wanted;
	}

	/**
	 * Whether AI authoring is unlimited this month (paid plans only).
	 * The Free plan is capped at 50 AI fixes per month.
	 *
	 * @return bool
	 */
	public static function allows_unlimited_fixes() {
		return self::is_paid();
	}

	/**
	 * Whether low-risk fixes may be auto-applied (Solo and above).
	 *
	 * @return bool
	 */
	public static function allows_auto_apply() {
		return self::is_at_least( self::PLAN_SOLO );
	}

	/**
	 * Whether the public statement is re-published on every change
	 * (Solo and above). On Free it is published once, on activation.
	 *
	 * @return bool
	 */
	public static function allows_statement_republish() {
		return self::is_at_least( self::PLAN_SOLO );
	}

	/**
	 * Whether per-site terminology memory is available (Studio and above).
	 *
	 * @return bool
	 */
	public static function allows_terminology() {
		return self::is_at_least( self::PLAN_STUDIO );
	}

	/**
	 * Whether the agency dashboard and client reporting are available
	 * (Agency only).
	 *
	 * @return bool
	 */
	public static function allows_agency_dashboard() {
		return self::PLAN_AGENCY === self::current_plan();
	}

	/**
	 * Audit log retention in days for the current plan.
	 *
	 * Paid (including a site running on its cached paid plan inside
	 * the grace period): 12 months. Free: 30 days.
	 *
	 * @return int
	 */
	public static function audit_retention_days() {
		return self::is_paid() ? self::PAID_AUDIT_RETENTION_DAYS : self::FREE_AUDIT_RETENTION_DAYS;
	}

	/**
	 * The retention floor the daily prune must never go below: the
	 * paid 12 months while a cached paid plan is still inside its
	 * grace period, 0 otherwise. The daily maintenance prunes to
	 * max( audit_retention_days(), cached_retention_days() ), so a
	 * transient Freemius outage can never shrink the prune window
	 * below the last known paid retention.
	 *
	 * @return int
	 */
	public static function cached_retention_days() {
		return false !== self::cached_paid_plan() ? self::PAID_AUDIT_RETENTION_DAYS : 0;
	}

	/**
	 * Human-readable name of the current plan.
	 *
	 * @return string
	 */
	public static function plan_label() {
		return self::plan_label_for( self::current_plan() );
	}

	/**
	 * Human-readable name of a plan slug.
	 *
	 * @param string $plan Plan slug.
	 * @return string
	 */
	public static function plan_label_for( $plan ) {
		switch ( $plan ) {
			case self::PLAN_SOLO:
				return __( 'Solo', 'sourcefix' );
			case self::PLAN_STUDIO:
				return __( 'Studio', 'sourcefix' );
			case self::PLAN_AGENCY:
				return __( 'Agency', 'sourcefix' );
			default:
				return __( 'Free', 'sourcefix' );
		}
	}

	/**
	 * URL the user can visit to upgrade. When Freemius is active this is
	 * the in-dashboard pricing page; otherwise it is the product site.
	 *
	 * @return string
	 */
	public static function upgrade_url() {
		if ( self::is_freemius_active() ) {
			return sourcefix_fs()->get_upgrade_url();
		}
		return 'https://usesourcefix.com/#pricing';
	}
}
