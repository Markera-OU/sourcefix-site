<?php
/**
 * Storage for SourceFix: the fix queue (approval history) and the audit log.
 *
 * The fixes table is the per-site approval history the product is built on:
 * every proposed fix, what the site owner decided, and when. The audit log
 * records every fix actually applied and every statement publication, and
 * is what the public statement is built from.
 *
 * @package SourceFix
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SourceFix_Store {

	/**
	 * Fix statuses.
	 */
	const STATUS_PENDING  = 'pending';
	const STATUS_APPROVED = 'approved';
	const STATUS_REJECTED = 'rejected';
	const STATUS_APPLIED  = 'applied';

	/**
	 * Fix types.
	 */
	const TYPE_ALT     = 'alt';
	const TYPE_LINK    = 'link';
	const TYPE_HEADING = 'heading';

	/**
	 * Table name for fixes.
	 *
	 * @return string
	 */
	public static function fixes_table() {
		global $wpdb;
		return $wpdb->prefix . 'sourcefix_fixes';
	}

	/**
	 * Table name for the audit log.
	 *
	 * @return string
	 */
	public static function audit_table() {
		global $wpdb;
		return $wpdb->prefix . 'sourcefix_audit';
	}

	/**
	 * Create the tables. Safe to call on every activation.
	 */
	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();

		$sql_fixes = 'CREATE TABLE ' . self::fixes_table() . ' (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			post_id bigint(20) unsigned NOT NULL,
			field_type varchar(20) NOT NULL,
			target text NOT NULL,
			original_text text NOT NULL,
			proposed_text text NOT NULL,
			occurrence bigint(20) unsigned NOT NULL DEFAULT 1,
			status varchar(20) NOT NULL DEFAULT "pending",
			source varchar(20) NOT NULL DEFAULT "ai",
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			decided_at datetime NULL,
			PRIMARY KEY (id),
			KEY post_id (post_id),
			KEY status (status)
		) ' . $charset . ';';

		$sql_audit = 'CREATE TABLE ' . self::audit_table() . ' (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			post_id bigint(20) unsigned NOT NULL,
			action varchar(40) NOT NULL,
			detail text NOT NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY post_id (post_id),
			KEY created_at (created_at)
		) ' . $charset . ';';

		dbDelta( $sql_fixes );
		dbDelta( $sql_audit );
	}

	/**
	 * Add a proposed fix to the queue. Returns the new row id, or 0.
	 * A fix for the same post, type, target, and occurrence that is
	 * still pending is not duplicated; the existing row is returned
	 * instead.
	 *
	 * The occurrence (audit H-8) identifies WHICH element the fix is
	 * for when a post contains several identical ones: it is the
	 * 1-based index of the element among all elements with the same
	 * target in the content, in document order — counted among ALL
	 * matching elements, not only the ones still unfixed, so the
	 * number stays stable as earlier occurrences get fixed. Legacy
	 * rows (created before this column existed) have occurrence 1,
	 * which means "the first matching element", as before.
	 *
	 * @param int    $post_id       Post ID.
	 * @param string $field_type    One of alt, link, heading.
	 * @param string $target        Identifier for the element (image src, link href, heading text).
	 * @param string $original_text The text as found in the content.
	 * @param string $proposed_text The proposed fix.
	 * @param string $source        ai or manual.
	 * @param int    $occurrence    1-based index among identical elements (default 1).
	 * @return int
	 */
	public static function add_fix( $post_id, $field_type, $target, $original_text, $proposed_text, $source = 'ai', $occurrence = 1 ) {
		global $wpdb;

		$existing = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT id FROM ' . self::fixes_table() . ' WHERE post_id = %d AND field_type = %s AND target = %s AND occurrence = %d AND status = %s',
				$post_id,
				$field_type,
				$target,
				max( 1, (int) $occurrence ),
				self::STATUS_PENDING
			)
		);
		if ( $existing ) {
			return (int) $existing;
		}

		$inserted = $wpdb->insert(
			self::fixes_table(),
			array(
				'post_id'       => $post_id,
				'field_type'    => $field_type,
				'target'        => $target,
				'original_text' => $original_text,
				'proposed_text' => $proposed_text,
				'occurrence'    => max( 1, (int) $occurrence ),
				'status'        => self::STATUS_PENDING,
				'source'        => $source,
			),
			array( '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s' )
		);
		return $inserted ? (int) $wpdb->insert_id : 0;
	}

	/**
	 * Find the pending fix for one specific element (audit H-8).
	 * Used by the scanner to reuse an already-proposed fix instead of
	 * authoring the same fix again (and spending another AI call) on a
	 * re-scan, and by the re-scan after an apply to check what is
	 * still open for this element.
	 *
	 * @param int    $post_id    Post ID.
	 * @param string $field_type One of alt, link, heading.
	 * @param string $target     Identifier for the element.
	 * @param int    $occurrence 1-based index among identical elements.
	 * @return object|null
	 */
	public static function find_pending_fix( $post_id, $field_type, $target, $occurrence = 1 ) {
		global $wpdb;
		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . self::fixes_table() . ' WHERE post_id = %d AND field_type = %s AND target = %s AND occurrence = %d AND status = %s',
				$post_id,
				$field_type,
				$target,
				max( 1, (int) $occurrence ),
				self::STATUS_PENDING
			)
		);
	}

	/**
	 * Count fixes for one post, optionally filtered by status.
	 * Used after an apply + re-scan to record how many fixes are
	 * still open for the post (audit H-8).
	 *
	 * @param int    $post_id Post ID.
	 * @param string $status  Status filter, or '' for all.
	 * @return int
	 */
	public static function count_fixes_for_post( $post_id, $status = '' ) {
		global $wpdb;
		if ( $status ) {
			return (int) $wpdb->get_var(
				$wpdb->prepare(
					'SELECT COUNT(*) FROM ' . self::fixes_table() . ' WHERE post_id = %d AND status = %s',
					$post_id,
					$status
				)
			);
		}
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM ' . self::fixes_table() . ' WHERE post_id = %d',
				$post_id
			)
		);
	}

	/**
	 * Get one fix row.
	 *
	 * @param int $id Fix id.
	 * @return object|null
	 */
	public static function get_fix( $id ) {
		global $wpdb;
		return $wpdb->get_row(
			$wpdb->prepare( 'SELECT * FROM ' . self::fixes_table() . ' WHERE id = %d', $id )
		);
	}

	/**
	 * Get fixes, optionally filtered by status.
	 *
	 * @param string $status Status filter, or '' for all.
	 * @param int    $limit  Max rows.
	 * @param int    $offset Offset.
	 * @return array
	 */
	public static function get_fixes( $status = '', $limit = 50, $offset = 0 ) {
		global $wpdb;
		if ( $status ) {
			return $wpdb->get_results(
				$wpdb->prepare(
					'SELECT * FROM ' . self::fixes_table() . ' WHERE status = %s ORDER BY created_at DESC LIMIT %d OFFSET %d',
					$status,
					$limit,
					$offset
				)
			);
		}
		return $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . self::fixes_table() . ' ORDER BY created_at DESC LIMIT %d OFFSET %d',
				$limit,
				$offset
			)
		);
	}

	/**
	 * Count fixes by status.
	 *
	 * @param string $status Status filter, or '' for all.
	 * @return int
	 */
	public static function count_fixes( $status = '' ) {
		global $wpdb;
		if ( $status ) {
			return (int) $wpdb->get_var(
				$wpdb->prepare(
					'SELECT COUNT(*) FROM ' . self::fixes_table() . ' WHERE status = %s',
					$status
				)
			);
		}
		return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::fixes_table() );
	}

	/**
	 * Set a fix's status (and decided_at when it leaves pending).
	 *
	 * @param int    $id     Fix id.
	 * @param string $status New status.
	 * @return bool
	 */
	public static function set_fix_status( $id, $status ) {
		global $wpdb;
		$data = array( 'status' => $status );
		if ( self::STATUS_PENDING !== $status ) {
			$data['decided_at'] = current_time( 'mysql' );
		}
		return false !== $wpdb->update(
			self::fixes_table(),
			$data,
			array( 'id' => $id ),
			array( '%s', '%s' ),
			array( '%d' )
		);
	}

	/**
	 * Update a fix's proposed text (the admin may edit it before approving).
	 *
	 * @param int    $id   Fix id.
	 * @param string $text New proposed text.
	 * @return bool
	 */
	public static function set_fix_proposed_text( $id, $text ) {
		global $wpdb;
		return false !== $wpdb->update(
			self::fixes_table(),
			array( 'proposed_text' => $text ),
			array( 'id' => $id ),
			array( '%s' ),
			array( '%d' )
		);
	}

	/**
	 * Append one audit log entry.
	 *
	 * @param int    $post_id Post ID (0 for site-wide events).
	 * @param string $action  Short action slug.
	 * @param string $detail  Human-readable detail.
	 */
	public static function audit_log( $post_id, $action, $detail ) {
		global $wpdb;
		$wpdb->insert(
			self::audit_table(),
			array(
				'post_id' => $post_id,
				'action'  => $action,
				'detail'  => $detail,
			),
			array( '%d', '%s', '%s' )
		);
	}

	/**
	 * Get audit log entries, newest first.
	 *
	 * @param int $limit  Max rows.
	 * @param int $offset Offset.
	 * @return array
	 */
	public static function get_audit_log( $limit = 50, $offset = 0 ) {
		global $wpdb;
		return $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . self::audit_table() . ' ORDER BY created_at DESC LIMIT %d OFFSET %d',
				$limit,
				$offset
			)
		);
	}

	/**
	 * Count audit log entries.
	 *
	 * @return int
	 */
	public static function count_audit_log() {
		global $wpdb;
		return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::audit_table() );
	}

	/**
	 * Get the applied fixes used to build the public statement.
	 *
	 * @param int $limit Max rows.
	 * @return array
	 */
	public static function get_applied_fixes( $limit = 200 ) {
		global $wpdb;
		return $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . self::fixes_table() . ' WHERE status = %s ORDER BY decided_at DESC LIMIT %d',
				self::STATUS_APPLIED,
				$limit
			)
		);
	}

	/**
	 * Monthly AI-fix counter (free tier: 50 AI-authored fixes per month).
	 * Rolls over automatically at the start of a new calendar month.
	 *
	 * @return int Fixes used this month.
	 */
	public static function monthly_fix_count() {
		$month = gmdate( 'Y-m' );
		$stored = get_option( 'sourcefix_month_key', '' );
		if ( $stored !== $month ) {
			update_option( 'sourcefix_month_key', $month );
			update_option( 'sourcefix_month_count', 0 );
			return 0;
		}
		return (int) get_option( 'sourcefix_month_count', 0 );
	}

	/**
	 * Increment the monthly AI-fix counter.
	 */
	public static function increment_monthly_fix_count() {
		$count = self::monthly_fix_count();
		update_option( 'sourcefix_month_count', $count + 1 );
	}

	/**
	 * Whether the free monthly AI-fix allowance is exhausted.
	 *
	 * @return bool
	 */
	public static function monthly_cap_reached() {
		return self::monthly_fix_count() >= SOURCEFIX_FREE_MONTHLY_FIXES;
	}

	/**
	 * Per-site terminology memory (Studio and above).
	 *
	 * A map of terms to the site's preferred wording, one per line in the
	 * settings ("term: preferred text"). The scanner includes it in the
	 * authoring request so the AI writes alt text and headings in the
	 * site's own words. Stored as a plain option; the licensing class
	 * decides whether it is used.
	 *
	 * @return array Map of lowercase term => preferred text.
	 */
	public static function get_terminology() {
		$raw = get_option( 'sourcefix_terminology', '' );
		$map = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $raw ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || false === strpos( $line, ':' ) ) {
				continue;
			}
			list( $term, $preferred ) = explode( ':', $line, 2 );
			$term      = strtolower( trim( $term ) );
			$preferred = trim( $preferred );
			if ( '' !== $term && '' !== $preferred ) {
				$map[ $term ] = $preferred;
			}
		}
		return $map;
	}

	/**
	 * Render the terminology map as the context line sent to the backend.
	 *
	 * @return string Empty when no terminology is set.
	 */
	public static function terminology_context() {
		$map = self::get_terminology();
		if ( empty( $map ) ) {
			return '';
		}
		$parts = array();
		foreach ( $map as $term => $preferred ) {
			$parts[] = '"' . $term . '" means "' . $preferred . '"';
		}
		return 'Site terminology: ' . implode( '; ', $parts ) . '.';
	}

	/**
	 * Delete audit log entries older than the given number of days.
	 * Used by the daily maintenance task to enforce the plan's audit
	 * retention (Free: 30 days, paid: 12 months).
	 *
	 * @param int $days Retention in days.
	 * @return int Number of rows deleted.
	 */
	public static function prune_audit_log( $days ) {
		global $wpdb;
		$days = max( 1, (int) $days );
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
		$deleted = $wpdb->query(
			$wpdb->prepare(
				'DELETE FROM ' . self::audit_table() . ' WHERE created_at < %s',
				$cutoff
			)
		);
		return false === $deleted ? 0 : (int) $deleted;
	}
}
