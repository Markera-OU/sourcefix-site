<?php
/**
 * Publish-time wiring: schedule the scan, run it in the background.
 *
 * Audit H-7: the publish-time scan used to run synchronously inside
 * `save_post`, one backend call per image at up to 30 s each plus a
 * heading call, so a post with 10 images could block publishing for
 * up to ~5 minutes. Publishing now returns immediately; the scan runs
 * shortly after in the background.
 *
 * Mechanism: a WP-Cron single event (`sourcefix_scan_post`), kicked
 * immediately with `spawn_cron()`. WP-Cron is the mechanism plain
 * WordPress ships for exactly this — no extra dependency, no new
 * endpoint, no new auth surface:
 *
 * - The event is stored in the options table, so if the immediate
 *   loopback kick fails (loopback blocked, single-threaded dev
 *   server), the scan still runs on the next visitor request. The
 *   scan is delayed, never lost.
 * - `spawn_cron()` fires a non-blocking request to wp-cron.php
 *   (timeout 0.01 s), so on a normal site the scan starts within
 *   seconds of publishing.
 * - If WP-Cron is disabled site-wide (DISABLE_WP_CRON), the event
 *   waits for the site's external cron to hit wp-cron.php — the
 *   standard WordPress contract for scheduled work.
 * - A pending scan is de-duplicated (`wp_next_scheduled`): rapid
 *   re-saves do not stack events. The scheduled run re-fetches the
 *   post, so it always scans the latest content.
 *
 * Failure modes preserved from the synchronous path (see
 * class-sourcefix-scanner.php): a backend failure still queues the
 * fix for manual review (the scan never fails publishing); a post
 * that is deleted or unpublished before the background run is
 * skipped; the approval queue is populated exactly as before, and
 * the targeted-surgery applier (H-4) is unchanged.
 *
 * @package SourceFix
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Publish-time scan. Runs when a post or page is saved as published (new
 * publish or an update). Autosaves, revisions, and non-public post types
 * are skipped. The scan itself is scheduled in the background (see
 * sourcefix_schedule_scan); this handler only decides whether a scan is
 * needed and returns immediately, so publishing never waits on the
 * backend.
 *
 * @param int     $post_id Post ID.
 * @param WP_Post $post    Post object.
 * @param bool    $update  Whether this is an update.
 */
function sourcefix_scan_on_save( $post_id, $post, $update ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
		return;
	}
	if ( 'publish' !== $post->post_status ) {
		return;
	}
	if ( ! in_array( $post->post_type, array( 'post', 'page' ), true ) ) {
		return;
	}
	// Only scan when the content actually changed on an update.
	if ( $update ) {
		$old = get_post_meta( $post_id, '_sourcefix_content_hash', true );
		$new = md5( $post->post_content );
		if ( $old === $new ) {
			return;
		}
		update_post_meta( $post_id, '_sourcefix_content_hash', md5( $post->post_content ) );
	} else {
		update_post_meta( $post_id, '_sourcefix_content_hash', md5( $post->post_content ) );
	}

	sourcefix_schedule_scan( $post_id );
}

/**
 * Schedule a background scan for a post.
 *
 * De-duplicates: when a scan for this post is already scheduled (rapid
 * re-saves), no second event is added — the pending run re-fetches the
 * post and scans the latest content. Kicks WP-Cron immediately so the
 * scan starts within seconds instead of waiting for the next visitor.
 *
 * @param int $post_id Post ID.
 * @return bool True when a new event was scheduled, false when one was
 *              already pending or scheduling failed.
 */
function sourcefix_schedule_scan( $post_id ) {
	$args = array( (int) $post_id );
	if ( function_exists( 'wp_next_scheduled' ) && wp_next_scheduled( 'sourcefix_scan_post', $args ) ) {
		return false;
	}
	if ( ! wp_schedule_single_event( time(), 'sourcefix_scan_post', $args ) ) {
		return false;
	}
	// Non-blocking loopback to wp-cron.php (timeout 0.01 s): publishing
	// does not wait for it, and if it fails the event still runs on
	// the next visitor request.
	if ( function_exists( 'spawn_cron' ) ) {
		spawn_cron();
	}
	return true;
}

/**
 * Run a scheduled background scan (the `sourcefix_scan_post` cron
 * callback). Re-fetches the post so the scan sees the latest content,
 * skips posts that are gone or no longer published, then runs the
 * exact same scan as the old synchronous path — same queue rows, same
 * audit entries, same auto-apply rules.
 *
 * After the scan, the content hash is refreshed to the post's current
 * content: the scan may have applied fixes, and without the refresh a
 * later save with no user changes would look changed and schedule a
 * redundant rescan.
 *
 * @param int $post_id Post ID.
 */
function sourcefix_run_scheduled_scan( $post_id ) {
	$post = get_post( (int) $post_id );
	if ( ! $post || 'publish' !== $post->post_status || ! in_array( $post->post_type, array( 'post', 'page' ), true ) ) {
		return;
	}

	SourceFix_Scanner::scan_post( (int) $post_id, $post );

	$fresh = get_post( (int) $post_id );
	if ( $fresh ) {
		update_post_meta( (int) $post_id, '_sourcefix_content_hash', md5( $fresh->post_content ) );
	}
}

add_action( 'save_post', 'sourcefix_scan_on_save', 20, 3 );
add_action( 'sourcefix_scan_post', 'sourcefix_run_scheduled_scan' );
