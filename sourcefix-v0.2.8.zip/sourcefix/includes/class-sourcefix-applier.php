<?php
/**
 * Applies an approved fix to a post's content.
 *
 * - alt: sets the alt attribute on the image with the matching src.
 * - link: replaces the link text of the link with the matching href.
 * - heading: re-maps heading levels to the approved corrected structure
 *   AND applies the approved reworded heading text (audit H-8).
 *
 * Targeted surgery (audit H-4): each fix splices ONLY its own fragment
 * into the original post_content. The old code parsed the whole post with
 * DOMDocument and re-serialised it, which normalised entities, whitespace,
 * and attribute quoting and could mangle Gutenberg block-comment markers,
 * shortcodes, and inline <script>/<style> content. The new code matches
 * the exact element in the raw content with a regex, replaces only that
 * fragment (verified byte-identical outside it), and aborts — leaving the
 * fix pending for manual handling — when the fragment cannot be matched
 * unambiguously (no match, or a heading count that no longer matches
 * the approved list). Nothing else in the post is ever
 * re-serialised, re-quoted, or re-encoded.
 *
 * Element identity (audit H-8): alt/link fixes match by occurrence
 * index, not bare src/href — the Nth identical element gets the Nth
 * fix. The occurrence is the 1-based index among ALL elements with
 * the same target in the content, in document order, so it stays
 * stable as earlier occurrences get fixed.
 *
 * After a successful apply the post is re-scanned (audit H-8), so
 * remaining issues — a second identical image that still has no alt
 * text, a heading the fix did not cover — surface as new queue rows
 * instead of being silently marked applied.
 *
 * Applying a fix updates the post content, marks the fix applied, writes
 * an audit log entry, records a note on the revision the update creates
 * so the change is visible in post history, and refreshes the public
 * statement's date.
 *
 * @package SourceFix
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SourceFix_Applier {

	/**
	 * Why the last apply attempt aborted: 'not_found',
	 * 'count_mismatch', 'inner_markup', or 'splice_failed'. Empty
	 * when the last attempt succeeded or no attempt has run.
	 *
	 * @var string
	 */
	private static $last_abort_reason = '';

	/**
	 * Whether the last apply found the content already matching the
	 * approved fix exactly (audit H-8): every heading already has the
	 * approved level AND text, so there is nothing to write. Set only
	 * by apply_headings; apply_fix treats it as a successful apply.
	 *
	 * @var bool
	 */
	private static $last_apply_satisfied = false;

	/**
	 * Re-entrancy guard for the re-scan after apply (audit H-8).
	 * The re-scan never auto-applies, so it cannot call apply_fix
	 * itself; this is belt-and-braces for future callers.
	 *
	 * @var bool
	 */
	private static $in_rescan = false;

	/**
	 * Apply one fix by id. Returns true on success.
	 *
	 * @param int $fix_id Fix id.
	 * @return bool
	 */
	public static function apply_fix( $fix_id ) {
		$fix = SourceFix_Store::get_fix( $fix_id );
		if ( ! $fix ) {
			return false;
		}
		if ( SourceFix_Store::STATUS_APPLIED === $fix->status ) {
			return true;
		}

		$post = get_post( (int) $fix->post_id );
		if ( ! $post ) {
			return false;
		}

		self::$last_abort_reason = '';
		self::$last_apply_satisfied = false;
		$new_content = $post->post_content;
		$occurrence  = isset( $fix->occurrence ) ? max( 1, (int) $fix->occurrence ) : 1;
		switch ( $fix->field_type ) {
			case SourceFix_Store::TYPE_ALT:
				$new_content = self::apply_alt( $post->post_content, $fix->target, $fix->proposed_text, $occurrence );
				break;
			case SourceFix_Store::TYPE_LINK:
				$new_content = self::apply_link( $post->post_content, $fix->target, $fix->original_text, $fix->proposed_text, $occurrence );
				break;
			case SourceFix_Store::TYPE_HEADING:
				$new_content = self::apply_headings( $post->post_content, $fix->proposed_text );
				break;
			default:
				return false;
		}

		if ( null === $new_content ) {
			// Targeted surgery refused: the fragment was not found, was
			// ambiguous, or the splice verification failed. Leave the
			// fix pending (manual handling) and record why, instead of
			// rewriting the post.
			SourceFix_Store::audit_log(
				$post->ID,
				'fix_apply_aborted',
				sprintf(
					/* translators: %1$s: fix type, %2$s: abort reason, %3$s: fix target. */
					__( 'Did not apply the %1$s fix (%2$s) for %3$s; the post was left unchanged.', 'sourcefix' ),
					$fix->field_type,
					self::$last_abort_reason,
					$fix->target
				)
			);
			return false;
		}
		if ( $new_content === $post->post_content ) {
			if ( ! self::$last_apply_satisfied ) {
				return false;
			}
			// Audit H-8: the content already matches the approved fix
			// exactly (e.g. the heading was fixed by hand between the
			// scan and the approval). There is nothing to write, but
			// the approved state holds, so the fix is applied — not
			// left pending forever as an error.
			SourceFix_Store::set_fix_status( $fix_id, SourceFix_Store::STATUS_APPLIED );
			SourceFix_Store::audit_log(
				$post->ID,
				'fix_applied',
				sprintf(
					/* translators: %s: fix type. */
					__( 'Approved %s fix already matched the post content; marked applied without changing the post.', 'sourcefix' ),
					$fix->field_type
				)
			);
			SourceFix_Statement::touch();
			self::rescan_after_apply( $post->ID );
			return true;
		}

		$revision_before = self::latest_revision_id( $post->ID );
		$note            = 'SourceFix: ' . self::audit_detail( $fix );

		// Update the content without re-triggering the publish-time scan.
		remove_action( 'save_post', 'sourcefix_scan_on_save', 20 );
		$updated = wp_update_post(
			array(
				'ID'           => $post->ID,
				'post_content' => $new_content,
			),
			true
		);
		add_action( 'save_post', 'sourcefix_scan_on_save', 20, 3 );

		if ( is_wp_error( $updated ) || ! $updated ) {
			return false;
		}

		// Note the change on the revision this update created, so the
		// fix is visible in post history (the revision diff shows the
		// excerpt change). If revisions are disabled there is no
		// revision to note; the audit log below is the record then.
		self::note_revision( $post->ID, $revision_before, $note );

		update_post_meta( $post->ID, '_sourcefix_content_hash', md5( $new_content ) );

		SourceFix_Store::set_fix_status( $fix_id, SourceFix_Store::STATUS_APPLIED );
		SourceFix_Store::audit_log(
			$post->ID,
			'fix_applied',
			self::audit_detail( $fix )
		);
		SourceFix_Statement::touch();

		// Audit H-8: re-scan the updated post so whatever is still
		// wrong surfaces as queue rows instead of being silently
		// treated as fixed.
		self::rescan_after_apply( $post->ID );

		return true;
	}

	/**
	 * Re-scan a post after a fix was applied (audit H-8).
	 *
	 * Runs the publish-time scan over the post's current content with
	 * auto-apply disabled: the scan only queues what is still wrong
	 * (a second identical image that still has no alt text, a heading
	 * the fix did not cover) and never applies anything itself, so it
	 * cannot recurse into apply_fix. The number of fixes still
	 * pending for the post is recorded in the audit log; remaining
	 * issues stay queued and are reported, never silently marked
	 * applied.
	 *
	 * @param int $post_id Post ID.
	 */
	private static function rescan_after_apply( $post_id ) {
		if ( self::$in_rescan || ! class_exists( 'SourceFix_Scanner' ) ) {
			return;
		}
		self::$in_rescan = true;
		$post = get_post( (int) $post_id );
		if ( $post ) {
			SourceFix_Scanner::scan_post( (int) $post_id, $post, false );
			$remaining = method_exists( 'SourceFix_Store', 'count_fixes_for_post' )
				? SourceFix_Store::count_fixes_for_post( (int) $post_id, SourceFix_Store::STATUS_PENDING )
				: 0;
			SourceFix_Store::audit_log(
				(int) $post_id,
				'rescan_after_apply',
				sprintf(
					/* translators: %d: number of fixes still pending. */
					__( 'Re-scanned the post after applying a fix: %d fix(es) still pending.', 'sourcefix' ),
					$remaining
				)
			);
		}
		self::$in_rescan = false;
	}

	/**
	 * Human-readable audit detail for a fix.
	 *
	 * @param object $fix Fix row.
	 * @return string
	 */
	private static function audit_detail( $fix ) {
		switch ( $fix->field_type ) {
			case SourceFix_Store::TYPE_ALT:
				if ( '' === $fix->proposed_text ) {
					return sprintf(
						/* translators: %s: image file name or URL. */
						__( 'Set empty alt text (decorative image) for %s.', 'sourcefix' ),
						$fix->target
					);
				}
				return sprintf(
					/* translators: %1$s: image URL, %2$s: alt text. */
					__( 'Set alt text for %1$s: "%2$s".', 'sourcefix' ),
					$fix->target,
					$fix->proposed_text
				);
			case SourceFix_Store::TYPE_LINK:
				return sprintf(
					/* translators: %1$s: link URL, %2$s: new link text. */
					__( 'Changed link text for %1$s to "%2$s".', 'sourcefix' ),
					$fix->target,
					$fix->proposed_text
				);
			case SourceFix_Store::TYPE_HEADING:
				return sprintf(
					/* translators: %s: post title. */
					__( 'Corrected the heading structure of "%s".', 'sourcefix' ),
					get_the_title( $fix->post_id )
				);
			default:
				return __( 'Applied a fix.', 'sourcefix' );
		}
	}

	/**
	 * Set the alt attribute on the image with the given src.
	 *
	 * Splices ` alt="..."` into the matching <img> tag in the raw
	 * content. Only an image with no alt attribute qualifies. Audit
	 * H-8: the match is by occurrence index — the $occurrence-th
	 * image with this src in the content, in document order — so the
	 * second identical image gets the second fix instead of the first
	 * fix being marked applied while the second still has no alt text.
	 * The occurrence counts ALL images with this src, not only the
	 * ones still missing alt, so it stays stable as earlier
	 * occurrences get fixed. If the Nth image does not exist, or it
	 * already has an alt attribute, the fix aborts.
	 *
	 * @param string $content    Post content.
	 * @param string $src        Image src to match.
	 * @param string $alt        Alt text to set (may be empty for decorative images).
	 * @param int    $occurrence 1-based index among images with this src.
	 * @return string|null New content, or null on failure.
	 */
	private static function apply_alt( $content, $src, $alt, $occurrence = 1 ) {
		$matches = self::find_tags( $content, 'img' );
		$candidates = array();
		foreach ( $matches as $match ) {
			$attrs = self::parse_attributes( $match[0] );
			if ( ! isset( $attrs['src'] ) || $attrs['src'] !== $src ) {
				continue;
			}
			$candidates[] = $match;
		}
		$index = max( 1, (int) $occurrence ) - 1;
		if ( ! isset( $candidates[ $index ] ) ) {
			self::$last_abort_reason = 'not_found';
			return null;
		}
		$candidate = $candidates[ $index ];
		if ( self::has_attribute( $candidate[0], 'alt' ) ) {
			// This occurrence already has alt text: the fix is stale
			// (or was already applied to this element). Leave it
			// pending for manual handling rather than fixing the
			// wrong image.
			self::$last_abort_reason = 'not_found';
			return null;
		}

		$tag    = $candidate[0];
		$offset = $candidate[1];
		// Insert before the closing `>`; before the `/` for `<img ... />`.
		$insert_at = ( substr( rtrim( $tag ), -2 ) === '/>' ) ? strlen( $tag ) - 2 : strlen( $tag ) - 1;
		$new_tag = substr( $tag, 0, $insert_at ) . ' alt="' . esc_attr( $alt ) . '"' . substr( $tag, $insert_at );

		$new = self::splice_fragment( $content, $offset, strlen( $tag ), $new_tag );
		if ( null === $new ) {
			self::$last_abort_reason = 'splice_failed';
		}
		return $new;
	}

	/**
	 * Replace the text of the link with the given href and original text.
	 *
	 * Splices the escaped proposed text into the matching <a>…</a>
	 * element's inner fragment in the raw content. Audit H-8: the
	 * match is by occurrence index — the $occurrence-th link with this
	 * href in the content, in document order — so the second identical
	 * link gets the second fix. The occurrence counts ALL links with
	 * this href, not only the ones whose text still matches, so it
	 * stays stable as earlier occurrences get fixed. The chosen
	 * link's text must still equal the original text; if it does
	 * not, the fix aborts.
	 *
	 * @param string $content    Post content.
	 * @param string $href       Link href to match.
	 * @param string $original   Original link text to match.
	 * @param string $proposed   New link text.
	 * @param int    $occurrence 1-based index among links with this href.
	 * @return string|null New content, or null on failure.
	 */
	private static function apply_link( $content, $href, $original, $proposed, $occurrence = 1 ) {
		$pattern = '/<a\b(?:[^>"\']|"[^"]*"|\'[^\']*\')*>(.*?)<\/a\s*>/is';
		if ( ! preg_match_all( $pattern, $content, $matches, PREG_OFFSET_CAPTURE ) ) {
			self::$last_abort_reason = 'not_found';
			return null;
		}
		$candidates = array();
		foreach ( $matches[0] as $i => $match ) {
			$full  = $match[0];
			$attrs = self::parse_attributes( $full );
			if ( ! isset( $attrs['href'] ) || $attrs['href'] !== $href ) {
				continue;
			}
			$candidates[] = array(
				'inner'        => $matches[1][ $i ][0],
				'inner_offset' => $matches[1][ $i ][1],
			);
		}
		$index = max( 1, (int) $occurrence ) - 1;
		if ( ! isset( $candidates[ $index ] ) ) {
			self::$last_abort_reason = 'not_found';
			return null;
		}
		$candidate = $candidates[ $index ];
		$text = trim( preg_replace( '/\s+/', ' ', html_entity_decode( wp_strip_all_tags( $candidate['inner'] ), ENT_QUOTES, 'UTF-8' ) ) );
		if ( $text !== $original ) {
			self::$last_abort_reason = 'not_found';
			return null;
		}

		$new = self::splice_fragment(
			$content,
			$candidate['inner_offset'],
			strlen( $candidate['inner'] ),
			esc_html( $proposed )
		);
		if ( null === $new ) {
			self::$last_abort_reason = 'splice_failed';
		}
		return $new;
	}

	/**
	 * Re-map heading levels to the approved corrected structure AND
	 * apply the approved reworded heading text (audit H-8).
	 * The proposed text is headings, one per line, in "H1: ..."/"H2: ..."
	 * format, in the same order as the headings in the content.
	 *
	 * What the user approves in the queue is what gets applied: the
	 * AI rewords headings as well as re-levelling them, and the queue
	 * shows the reworded text for approval, so the applier applies
	 * both. (The alternative — never proposing text changes — would
	 * throw away AI output the admin already approved.) Splices only
	 * the changed fragments in the raw content: the open/close tag
	 * names for a level change, the inner fragment for a text change.
	 * The heading count must still match the approved list exactly;
	 * a mismatch means the content changed since the scan, and the
	 * fix aborts. A heading whose inner content carries markup (e.g.
	 * <em>) cannot have its text replaced without dropping that
	 * markup, so when its approved text differs the whole fix aborts
	 * with 'inner_markup' for manual handling — the H-4 rule that a
	 * fix is never half-applied. When every heading already has the
	 * approved level AND text, the content is returned unchanged and
	 * the satisfied flag is set, so apply_fix marks the fix applied
	 * instead of erroring (audit H-8: a text-only change with no
	 * level change must apply, not error).
	 *
	 * @param string $content  Post content.
	 * @param string $proposed Corrected headings, one per line.
	 * @return string|null New content, or null on failure. Unchanged
	 *                     content (non-null) when already satisfied.
	 */
	private static function apply_headings( $content, $proposed ) {
		self::$last_apply_satisfied = false;
		$lines = array();
		foreach ( preg_split( '/\r\n|\r|\n/', $proposed ) as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}
			if ( preg_match( '/^H([1-6]):\s*(.*)$/i', $line, $m ) ) {
				$lines[] = array(
					'level' => (int) $m[1],
					'text'  => $m[2],
				);
			}
		}
		if ( empty( $lines ) ) {
			self::$last_abort_reason = 'not_found';
			return null;
		}

		$pattern = '/<(h[1-6])\b(?:[^>"\']|"[^"]*"|\'[^\']*\')*>(.*?)<\/\1\s*>/is';
		if ( ! preg_match_all( $pattern, $content, $matches, PREG_OFFSET_CAPTURE ) ) {
			self::$last_abort_reason = 'not_found';
			return null;
		}
		$headings = $matches[0];
		if ( count( $headings ) !== count( $lines ) ) {
			self::$last_abort_reason = 'count_mismatch';
			return null;
		}

		// Splice right to left so earlier offsets stay valid. Within
		// one heading, splice close tag, then inner text, then open
		// tag: each splice sits at a lower offset than the previous
		// one, so no offset is invalidated.
		$new     = $content;
		$changed = false;
		for ( $i = count( $headings ) - 1; $i >= 0; $i-- ) {
			$full       = $headings[ $i ][0];
			$offset     = $headings[ $i ][1];
			$inner      = $matches[2][ $i ][0];
			$inner_off  = $matches[2][ $i ][1];
			$old_level  = (int) substr( strtolower( $matches[1][ $i ][0] ), 1 );
			$new_level  = $lines[ $i ]['level'];
			$old_text   = trim( preg_replace( '/\s+/', ' ', html_entity_decode( wp_strip_all_tags( $inner ), ENT_QUOTES, 'UTF-8' ) ) );
			$new_text   = $lines[ $i ]['text'];
			$text_differs = ( $new_text !== $old_text );

			if ( $text_differs && false !== strpos( $inner, '<' ) ) {
				// Inner markup (e.g. <em>) would be lost by a text
				// splice. Abort the whole fix for manual handling
				// rather than applying it half-way.
				self::$last_abort_reason = 'inner_markup';
				return null;
			}

			// The heading close tag is the LAST `</` in the match: inner
			// markup may contain its own close tags (e.g. </em>), and the
			// regex ends the match at the heading's own </hN>.
			$close_pos = strrpos( $full, '</' );
			if ( false === $close_pos && $new_level !== $old_level ) {
				self::$last_abort_reason = 'splice_failed';
				return null;
			}
			if ( $new_level !== $old_level ) {
				// Close tag first (higher offset), then the open tag.
				$new = self::splice_fragment( $new, $offset + $close_pos + 2, 2, 'h' . $new_level );
				if ( null === $new ) {
					self::$last_abort_reason = 'splice_failed';
					return null;
				}
				$changed = true;
			}
			if ( $text_differs ) {
				$new = self::splice_fragment( $new, $inner_off, strlen( $inner ), esc_html( $new_text ) );
				if ( null === $new ) {
					self::$last_abort_reason = 'splice_failed';
					return null;
				}
				$changed = true;
			}
			if ( $new_level !== $old_level ) {
				$new = self::splice_fragment( $new, $offset + 1, 2, 'h' . $new_level );
				if ( null === $new ) {
					self::$last_abort_reason = 'splice_failed';
					return null;
				}
			}
		}
		if ( ! $changed ) {
			// Every heading already has the approved level and text.
			self::$last_apply_satisfied = true;
			return $content;
		}
		return $new;
	}

	/**
	 * Find all occurrences of one HTML open tag in raw content, with
	 * offsets. The pattern respects quoted attribute values, so a `>`
	 * inside an attribute value does not end the tag early.
	 *
	 * @param string $content Post content.
	 * @param string $tag     Tag name, e.g. 'img'.
	 * @return array List of array( full tag string, byte offset ).
	 */
	private static function find_tags( $content, $tag ) {
		$pattern = '/<' . $tag . '\b(?:[^>"\']|"[^"]*"|\'[^\']*\')*>/i';
		if ( ! preg_match_all( $pattern, $content, $matches, PREG_OFFSET_CAPTURE ) ) {
			return array();
		}
		return $matches[0];
	}

	/**
	 * Parse the attributes of one raw tag string into name => value
	 * (values HTML-entity-decoded, so they compare equal to the
	 * scanner's DOM-decoded values). Attribute names are lower-cased.
	 *
	 * @param string $tag Raw tag, e.g. '<img src="x" class="y">'.
	 * @return array
	 */
	private static function parse_attributes( $tag ) {
		$attrs = array();
		if ( preg_match_all( '/([a-zA-Z_:][a-zA-Z0-9_.\-:]*)\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>\/]+))/', $tag, $m, PREG_SET_ORDER ) ) {
			foreach ( $m as $match ) {
				$value = '';
				if ( isset( $match[2] ) && '' !== $match[2] ) {
					$value = $match[2];
				} elseif ( isset( $match[3] ) && '' !== $match[3] ) {
					$value = $match[3];
				} elseif ( isset( $match[4] ) ) {
					$value = $match[4];
				}
				$attrs[ strtolower( $match[1] ) ] = html_entity_decode( $value, ENT_QUOTES, 'UTF-8' );
			}
		}
		return $attrs;
	}

	/**
	 * Whether a raw tag string carries an attribute (valued or boolean),
	 * e.g. an existing alt attribute on an <img>.
	 *
	 * @param string $tag  Raw tag.
	 * @param string $name Attribute name.
	 * @return bool
	 */
	private static function has_attribute( $tag, $name ) {
		return (bool) preg_match(
			'/\s' . preg_quote( $name, '/' ) . '(?:\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>\/]+))?(?=\s|\/?>)/i',
			$tag
		);
	}

	/**
	 * Replace one fragment of the original content and prove the rest is
	 * byte-identical: the result must be the original with exactly the
	 * fragment at $offset replaced by $replacement, nothing else touched.
	 *
	 * @param string $content     Original content.
	 * @param int    $offset      Byte offset of the fragment.
	 * @param int    $old_length  Byte length of the fragment to replace.
	 * @param string $replacement Replacement fragment.
	 * @return string|null New content, or null if the check fails.
	 */
	private static function splice_fragment( $content, $offset, $old_length, $replacement ) {
		$new = substr( $content, 0, $offset ) . $replacement . substr( $content, $offset + $old_length );
		if ( substr( $new, 0, $offset ) !== substr( $content, 0, $offset ) ) {
			return null;
		}
		if ( substr( $new, $offset + strlen( $replacement ) ) !== substr( $content, $offset + $old_length ) ) {
			return null;
		}
		return $new;
	}

	/**
	 * Newest revision id for a post, or 0 when there is none.
	 *
	 * @param int $post_id Post ID.
	 * @return int
	 */
	private static function latest_revision_id( $post_id ) {
		if ( ! function_exists( 'wp_get_post_revisions' ) ) {
			return 0;
		}
		$revisions = wp_get_post_revisions( $post_id );
		if ( empty( $revisions ) ) {
			return 0;
		}
		return (int) max( array_keys( $revisions ) );
	}

	/**
	 * Record a note on the revision created by an update: set the new
	 * revision's excerpt to the note, so the change shows in post
	 * history (the revision comparison displays the excerpt change).
	 * No-op when no new revision was created.
	 *
	 * @param int    $post_id         Post ID.
	 * @param int    $revision_before Newest revision id before the update.
	 * @param string $note            Note text.
	 */
	private static function note_revision( $post_id, $revision_before, $note ) {
		$new_revision = self::latest_revision_id( $post_id );
		if ( $new_revision <= $revision_before ) {
			return;
		}
		global $wpdb;
		$wpdb->update(
			$wpdb->posts,
			array( 'post_excerpt' => $note ),
			array( 'ID' => $new_revision ),
			array( '%s' ),
			array( '%d' )
		);
	}
}
